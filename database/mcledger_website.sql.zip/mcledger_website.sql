-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 16, 2020 at 04:53 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.2.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mcledger_website`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` smallint(5) UNSIGNED NOT NULL,
  `author_id` smallint(5) UNSIGNED NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `details` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `banner` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pdf_file` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `pdf_file_title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `tags` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_desc` text COLLATE utf8_unicode_ci NOT NULL,
  `meta_keywords` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `sort` mediumint(8) UNSIGNED NOT NULL,
  `views` mediumint(8) UNSIGNED NOT NULL,
  `likes` smallint(5) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `category_id`, `author_id`, `slug`, `title`, `details`, `image`, `banner`, `pdf_file`, `pdf_file_title`, `tags`, `meta_desc`, `meta_keywords`, `active`, `featured`, `sort`, `views`, `likes`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 'all-you-need-to-know-about-fta-audit', 'All You Need To Know About FTA Audit', '<h1 style=\"text-align:center\"><strong>All You Need To Know About FTA Audit</strong></h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>The UAE government has already implemented VAT on the supply of taxable goods and services starting from January 01, 2018. The companies that are required to pay taxes can be audited by the Federal Tax Authority (FTA) to determine their tax compliance.</strong></h4>\r\n\r\n<h2>&nbsp;</h2>\r\n\r\n<h2 style=\"text-align:center\"><img alt=\"\" class=\"aligncenter\" src=\"https://mcledger.co/wp-content/uploads/2019/07/for-linked-link-on-facebook-700x368.png\" style=\"height:368px; width:700px\" /></h2>\r\n\r\n<h4>&nbsp;</h4>\r\n\r\n<p><strong>Reading time: 5 minutes</strong> &nbsp;</p>\r\n\r\n<h3><strong>What is Tax FTA Audit?</strong></h3>\r\n\r\n<p>A tax audit is a government&rsquo;s assessment of a company about their responsibility as a taxable entity. This kind of audit is conducted by the FTA to ensure that every liability is paid and every tax due is collected and given to the government within the timeframe given. The government also assesses whether the companies are following certain responsibilities that apply to their business as per the tax laws (VAT Law, Excise Tax Law, etc.). &nbsp;</p>\r\n\r\n<h3><strong>Detailed procedure</strong></h3>\r\n\r\n<p>The FTA will check the returns and other details. There may not be a specific reason for the FTA to conduct an audit of a company. They can conduct it based on any reason or whenever they want. A notice will be issued to the company at least five days before the scheduled audit date. It will contain details such as the audit schedule, place, involved parties, reason (if anything particular), etc. The auditor/s and the company will meet at the scheduled place at the scheduled time and the process will begin. The auditor may ask for business records, in original and/or copies, and take samples of goods and other assets as available at the place at the time. The tax audit is required to be conducted during the official FTA working hours unless the Director-General decides to conduct the audit of business outside regular hours, in an exceptional case. The company subject to tax audit along with its legal representatives and tax agents are required to provide full assistance to the auditors for performing their task. If anything suspicious is found in the result of the audit that might impact the tax return, the authority may order a re-audit for further analysis. The audited person has the right to ask for the notification copy and related documents and be present during the auditing procedures that are conducted outside of the official places. It is the job of the FTA to review and verify the tax declarations of the tax-registered businesses. Business owners should expect FTA to inspect them in the future as part of a practice to ensure that the tax regime is working properly and being complied with by the eligible people. &nbsp;</p>\r\n\r\n<h3><strong>What can you do to be prepared for the audit?</strong></h3>\r\n\r\n<p>McLedger (formerly known as PicWPost) can help you be organized so that when your company is requested for an audit from FTA, you are all set up to face the tax audit without worrying about it. The list below shows the kinds of review that can be done to prepare you for an upcoming audit:</p>\r\n\r\n<h4><strong>Review of the system</strong></h4>\r\n\r\n<p>Since the tax has been announced to commence in the UAE on the first day of 2018, companies have ensured that every department is ready to face a new era. One of the most important items to be updated is the accounting software. The same should comply with the laws regarding <a href=\"https://mcledger.co/vat-in-the-uae/\">VAT accounting</a>. A review of the systems will ensure that there is no inconsistency with the recorded transactions.</p>\r\n\r\n<h4><strong>Review of calculations tax</strong></h4>\r\n\r\n<p>Companies must ensure that they are complying with the laws by checking that the calculation of both output and input taxes are correct. As a basic rule, the tax rate is 5% only. Any goods or services that fall under zero-rated and exempted tax should be treated as it is with documents for support.</p>\r\n\r\n<h4><strong>Review of VAT returns</strong></h4>\r\n\r\n<p>McLedger will review the VAT returns that need to be filed by the companies to ensure that returns will be prepared perfectly, values properly recorded in the right boxes, and the needed information is filled in. We make sure that it is filed within the timeframe provided by the FTA.</p>\r\n\r\n<h4><strong>Review of payment of tax due</strong></h4>\r\n\r\n<p>The correct amount of tax due should be paid on or before the due date. We will ensure that you are not drawing any negative attention from the FTA by missing the deadline for tax payment to the government. &nbsp;</p>\r\n\r\n<h4><strong>What is FTA Audit File (FAF)?</strong></h4>\r\n\r\n<p>Once the tax audit is initiated, the concerned business is required to produce all the information in a prescribed manner known as the Audit file. The format of the Audit file will be in FAF prescribed format in which all the information as required, needs to be submitted by the businesses. The FTA expects that the tax accounting software used by the business should be able to generate the Audit file in FAF format so that the businesses find it easier to respond promptly to FTA&#39;s requests. Unlike the VAT return, which is a summary level return, meaning only the consolidated details of sales, purchase, input VAT, output VAT, etc. are declared, the audit file, designed in FAF format, needs to be produced at invoice level. The format of the FTA audit file should be in &#39;comma separated value&#39;(.csv) and should include details mentioned below:</p>\r\n\r\n<h4><strong>Company Information</strong></h4>\r\n\r\n<p>The FAF file should include the following details of the company, as applicable.</p>\r\n\r\n<ol>\r\n	<li>Taxable Person Name (English)</li>\r\n	<li>Taxable Person Name (Arabic)</li>\r\n	<li>TRN Tax (Registration Number)</li>\r\n	<li>Tax Agency Name</li>\r\n	<li>TAN (Tax Agency Number)</li>\r\n	<li>Tax Agent Name</li>\r\n	<li>TAAN (Tax Agent Approval Number)</li>\r\n</ol>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h4><strong>Supplier and customer details</strong></h4>\r\n\r\n<p>The location of the customer and supplier i.e. the country or the Emirate (in case country is UAE) along with TRN, if applicable, should be provided. Also, you may need to assign the tax codes, like ZR for Zero-rated supplies, to identify the nature of supply. &nbsp;</p>\r\n\r\n<h4><strong>Transactions details</strong></h4>\r\n\r\n<p>In the FAF file, you need to report the details at each invoice level. The details such as invoice number, invoice date, invoice value, VAT amount, etc. need to be captured in the audit file. The following are the transaction details you need to capture in the FTA Audit File (FAF).</p>\r\n\r\n<ul>\r\n	<li>Purchase Invoices / Imports / Credit Notes/</li>\r\n	<li>Sales Invoices / Credit Note</li>\r\n	<li>Invoice No.</li>\r\n	<li>Document number</li>\r\n	<li>Permit No. - If available</li>\r\n	<li>Invoice Date</li>\r\n	<li>Transaction Date</li>\r\n	<li>Transaction ID</li>\r\n	<li>Any reference ID identifying the transaction</li>\r\n	<li>Line No. - The line number of the invoice etc. (in case of multiple items in invoice etc.)</li>\r\n	<li>Debit and Credit Amount - In Actual Currency and Converted to AED</li>\r\n	<li>VAT Amount - In Actual Currency and Converted to AED</li>\r\n</ul>\r\n\r\n<p>In case of payment transactions, you need to capture the payment date. Apart from the above-mentioned details, you also need to capture the description of goods and services along with the VAT code, details of adjustment like journal entry and comment stating rounding off is used if the values are rounded off. &nbsp;</p>\r\n\r\n<h4><strong>Essential advice:</strong></h4>\r\n\r\n<ol>\r\n	<li>Host to audit will likely be taxable person office, or as per FTA requirements.</li>\r\n	<li>Tax records, files, books of accounts and statements should be readily reachable.</li>\r\n	<li>Reconcile your revenue and purchases/expenses announced in VAT returns with actual books of accounts.</li>\r\n</ol>', NULL, NULL, '', '', '', 'UAE businesses that are required to pay taxes can be audited by Federal Tax Authority  to determine their tax compliance. Here\'s what you should know.', 'VAT, Audit, fta, federal tax authority, tax agents, Business owners, VAT returns, TRN, invoice, transaction, tax registration number, tax accounting software', 1, 0, 0, 1, 0, '2020-11-15 12:40:48', '2020-11-15 12:40:53'),
(2, 4, 1, 'new-vat-cash-refund-limit-for-tourists', 'New VAT Cash Refund Limit For Tourists', '<h1 style=\"text-align:center\"><strong>New VAT Cash Refund Limit For Tourists</strong></h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>The FTA has set daily maximum VAT cash refund limit at Dh7,000.</strong></h4>\r\n\r\n<p><img alt=\"\" class=\"aligncenter\" src=\"https://mcledger.co/wp-content/uploads/2019/09/New-VAT-Cash-Refund-limit-1.jpg\" style=\"height:698px; width:1200px\" /> &nbsp; <strong>Reading time: 1 minute</strong> &nbsp; The FTA Decision No. (1) of 2019 has been issued, which outlines the daily maximum limit for the VAT cash refund at Dh7,000. This limit has been set for tourists applying through the Tax Refunds for Tourists Scheme. &nbsp; Tax Refunds for Tourists Scheme came into effect in November 2018. The FTA asserted that efficiency, seamless procedures, speed, and accuracy in processing applications characterize this scheme. &nbsp; It&#39;s been stated that this new decision regarding the maximum amount a tourist can reclaim daily in cash aligns with UAE&#39;s strategy, which focuses on reducing the reliance on cash in financial transactions. This will enable benefits from advanced technological and digital infrastructure, which are essential for the development of the country&#39;s economy. This decision also follows the best practices by advanced economies. &nbsp; The FTA is committed to implementing the highest international standards across all its activities and services. This aligns with the UAE&#39;s vision to maintaining its competitiveness as the economy based on innovation and creativity, making it one of the best countries in the world by 2021. &nbsp; Although if you run your business here in the UAE, you can get all VAT related help from us! The main goal of McLedger is to ensure your financial health is in great shape while you focus on what you love most - your business and grow with the best insights in hand from industry experts with the least effort from your end. &nbsp; McLedger offers various packages at pocket-friendly prices to ensure you don&rsquo;t have to pay hefty cheques, save more, and grow more with your accountant in the app by your side. &nbsp; Learn all about McLedger and its unique features of how it can ease up your business financials in an instant by calling us on <strong>056 5224041</strong> now! &nbsp; &nbsp; <strong><em>The original article was published in Khaleej Times on July 8, 2019. You can find it <a href=\"https://www.khaleejtimes.com/business/vat-in-uae/uae-announces-daily-cash-refund-limit-of-dh7000-1\">here.</a></em></strong></p>', '2020/11/1605451375.jpg', NULL, '', '', '', 'FTA outlined daily maximum limit for VAT cash refund at Dh7,000 that is set for tourists applying via Tax Refunds for Tourists Scheme.', 'FTA, VAT, tax refund, transaction, business, UAE, federal tax authority, cash refund', 1, 0, 0, 0, 0, '2020-11-15 12:42:55', '2020-11-15 12:42:55'),
(3, 4, 1, 'vat-refunds-processed-via-official-website', 'VAT Refunds Processed Via Official Website', '<h1 style=\"text-align:center\">VAT Refunds Processed Via Official Website</h1>\r\n\r\n<h4 style=\"text-align:center\">Some bank users had been receiving emails from unidentified sources representing banks and financial institutions requesting personal data to help them declare their VAT refunds.</h4>\r\n\r\n<h4 style=\"text-align:center\">&nbsp;</h4>\r\n\r\n<p><img alt=\"\" class=\"aligncenter size-full wp-image-2745\" src=\"https://mcledger.co/wp-content/uploads/2019/10/Process-VAT-refunds-only-through-official-platforms.jpg\" /> &nbsp; <strong>Reading time: 1 minute</strong> &nbsp; It had been reported that some bank users had been receiving emails from unidentified sources representing banks and financial institutions requesting personal data to help them declare their Value Added Tax (VAT) refunds. The FTA emphasized that these are fraudulent messages and that it never asks people to disclose their data via e-mail, text, or over the phone. It reaffirmed that tax refunds are processed only through the authority&#39;s official website. &nbsp; The FTA defined that tax refund operations for legally eligible categories are conducted directly between the authority and the taxpayer, with the authority approaching registrants directly without any third-party interference. &nbsp; The authority also guaranteed that refunds are accomplished by availing the latest secure electronic systems available on the authority&rsquo;s website and that these systems meet the strict safety standards relating to financial transactions. It was also mentioned that tax refunds can only be made by using the registrant&rsquo;s bank&rsquo;s IBAN through its systems, which are electronically linked to the central bank. &nbsp; It was also highlighted that all transactions - registration, submitting tax returns, refunding tax for eligible candidates, etc. - can be completed with a few simple steps via the e-Services portal, available 24/7 on the FTA website: www.tax.gov.ae. &nbsp; &nbsp; &nbsp; <strong><em>The original article was published in Khaleej Times on September 10, 2019. You can find it <a href=\"https://www.khaleejtimes.com/business/vat-in-uae/uae-makes-new-vat-announcement-heres-how-it-affects-you\">here.</a></em></strong></p>', '2020/11/1605451422.jpg', NULL, '', '', '', 'The FTA defined that tax refund operations for legally eligible categories are conducted directly between the authority and the taxpayer.', 'VAT, fta, value added tax, transaction, tax refund, registration, tax return, federal tax authority', 1, 0, 0, 0, 0, '2020-11-15 12:43:42', '2020-11-15 12:43:42'),
(4, 2, 1, 'de-registration-vat-you-can-do', 'De-Registration: VAT You Can Do', '<h1 style=\"text-align: center;\">De-Registration: <em>VAT</em> You Can Do</h1>\r\n<h4 style=\"text-align: center;\"><strong>Can a business de-register? What are the circumstances under which de-registration may be considered?</strong></h4>\r\n&nbsp;\r\n\r\n<img class=\"size-full wp-image-2749 aligncenter\" src=\"https://mcledger.co/wp-content/uploads/2019/11/De-Registration-Vat-You-Can-Do.jpg\" alt=\"\" />\r\n\r\n&nbsp;\r\n\r\n<strong>Reading time: 2 minutes</strong>\r\n\r\n&nbsp;\r\n\r\nWondering if de-registration is a taxing job? Well, we are here to help! Let us explain <em>vat </em>we mean.\r\n\r\n&nbsp;\r\n<h4><strong>Let\'s go back to the start!</strong></h4>\r\n<a href=\"https://mcledger.co/vat-in-the-uae/\">Value Added Tax (VAT) is an indirect tax imposed on supplies of goods and services.</a> With the standard rate of 5%, businesses in the UAE are responsible for documenting income and cost.\r\n\r\nA business must register for VAT if they meet the mandatory threshold of AED 375,000, i.e. if the value of taxable supply exceeds this limit. A business can voluntarily choose to register for VAT if it meets the voluntary threshold of AED 187,500, i.e., if the value of taxable supply exceeds this limit.\r\n\r\n&nbsp;\r\n<h4><strong>What is a taxable supply?</strong></h4>\r\nA taxable supply is a supply of goods and services on which the tax can be levied.\r\n\r\nThere are benefits of having a TRN. If a business avails the TRN, it becomes a collection agent of the government. This is rewarding as the VAT on business expenses of any kind can be claimed.\r\n\r\n&nbsp;\r\n<h4><strong>But can you de-register?</strong></h4>\r\nDefinitely! A business can de-register under a few circumstances.\r\n<ol>\r\n 	<li>If a registrant stops making taxable supplies;</li>\r\n</ol>\r\n<ol start=\"2\">\r\n 	<li>If the business still makes taxable supplies, but its value in the past back-to-back 12 months is less than the voluntary threshold;</li>\r\n 	<li>If the business continues to make taxable supplies, but the value in the past continuous 12 months is less than the mandatory threshold, it can voluntarily apply for de-registration.</li>\r\n</ol>\r\nIn the first two cases, the person must apply for de-registration within 20 business days of the situation taking place. Administrative penalties will be imposed in case of failure to apply within the specified date.\r\n\r\nBusinesses face other situations where they consider canceling their VAT registration. We have listed a few cases where the companies choose to de-register.\r\n<ol>\r\n 	<li>Duplicate TRN\r\nThis is a situation where one company has different applications submitted and each one has a TRN issued. This requires the cancellation of one TRN.</li>\r\n 	<li>Company branch has a TRN\r\nIn this scenario, a company\'s branch has a separate TRN issued whereas the branch should have the main company\'s TRN.</li>\r\n 	<li>Meeting voluntary threshold\r\nIf a business meets the voluntary threshold and not the mandatory threshold, it has a choice not to have TRN.</li>\r\n 	<li>Canceling trade license</li>\r\n</ol>\r\nA business entity\'s TRN will be canceled if its trade license is canceled.\r\n\r\n&nbsp;\r\n<h4><strong>Wait, before you go...</strong></h4>\r\nNo person can de-register without having paid all the due taxes and penalties it owed during the period it was registered for VAT.\r\n\r\nHence, it is essential that a registrant satisfies the requirements by the Federal Tax Authority for canceling of VAT registration and it is important to be aware of this provision for them to timely utilize it.\r\n\r\nFor any help or inquiry regarding VAT, get in touch with us on <strong>056 522 4041</strong> or <strong>info@mcledger.co</strong>\r\n\r\n&nbsp;\r\n\r\n&nbsp;', '2020/11/1605451560.jpg', NULL, '', '', '', 'Can a business de-register? What are the circumstances under which de-registration may be considered?', 'VAT, Value Added Tax, indirect tax, TRN, VAT registration, Federal Tax Authority, tax registration authority', 1, 0, 0, 0, 0, '2020-11-15 12:46:00', '2020-11-15 12:46:00');

-- --------------------------------------------------------

--
-- Table structure for table `blog_authors`
--

CREATE TABLE `blog_authors` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `image` varchar(60) DEFAULT NULL,
  `details` text,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blog_authors`
--

INSERT INTO `blog_authors` (`id`, `slug`, `name`, `image`, `details`, `active`, `created_at`, `updated_at`) VALUES
(1, 'editor', 'Editor', NULL, '', 1, '2020-11-15 14:29:32', '2020-11-15 14:29:32');

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

CREATE TABLE `blog_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog_categories`
--

INSERT INTO `blog_categories` (`id`, `slug`, `title`, `active`, `created_at`, `updated_at`) VALUES
(1, 'mcledger', 'McLedger', 1, '2020-11-15 12:27:54', '2020-11-15 12:27:54'),
(2, 'vat', 'VAT', 1, '2020-11-15 12:28:02', '2020-11-15 12:28:02'),
(3, 'accounting-bookkeeping', 'Accounting & Bookkeeping', 1, '2020-11-15 12:28:12', '2020-11-15 12:28:12'),
(4, 'industry-news', 'Industry News', 1, '2020-11-15 12:28:19', '2020-11-15 12:28:19');

-- --------------------------------------------------------

--
-- Table structure for table `blog_comments`
--

CREATE TABLE `blog_comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `record_id` int(10) UNSIGNED NOT NULL,
  `model` varchar(30) NOT NULL,
  `name` varchar(80) NOT NULL,
  `email` varchar(60) NOT NULL,
  `comment` text NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blog_comments`
--

INSERT INTO `blog_comments` (`id`, `record_id`, `model`, `name`, `email`, `comment`, `active`, `created_at`, `updated_at`) VALUES
(1, 35, 'Blog', 'Marwan', 'marwan.nabil.mohamed@gmail.com', 'Yes, looks great', 1, '2019-12-10 13:34:38', '2019-12-10 13:37:08');

-- --------------------------------------------------------

--
-- Table structure for table `emails`
--

CREATE TABLE `emails` (
  `id` int(11) NOT NULL,
  `email_template_id` mediumint(8) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `subject` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `goto_inbox` tinyint(1) NOT NULL DEFAULT '0',
  `goto_email` tinyint(1) NOT NULL DEFAULT '0',
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `emails_bulk`
--

CREATE TABLE `emails_bulk` (
  `id` int(11) NOT NULL,
  `active_status` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `award_branches` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `goto_inbox` tinyint(1) NOT NULL,
  `goto_email` int(11) NOT NULL,
  `candidates_received` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'serialized object',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `enquiries`
--

CREATE TABLE `enquiries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) NOT NULL,
  `phone` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(500) NOT NULL,
  `replied` tinyint(1) NOT NULL DEFAULT '0',
  `from` varchar(30) NOT NULL,
  `to` varchar(30) NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `enquiries`
--

INSERT INTO `enquiries` (`id`, `name`, `phone`, `email`, `subject`, `message`, `replied`, `from`, `to`, `read`, `created_at`, `updated_at`) VALUES
(1, 'fdsfdsfds', '432432432', 'dsdsadsadsa@mmm.com', '', 'fdsfds fdsfds', 0, '', '', 0, '2019-11-14 22:04:00', '2019-11-14 22:04:00');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_reply`
--

CREATE TABLE `enquiry_reply` (
  `id` int(11) NOT NULL,
  `enquiry_id` int(10) UNSIGNED NOT NULL,
  `subject` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `admin_id` mediumint(8) UNSIGNED NOT NULL,
  `goto_email` tinyint(1) NOT NULL,
  `goto_inbox` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `join_requests`
--

CREATE TABLE `join_requests` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `join_as` enum('accountant','client','checker','3rdparty') NOT NULL DEFAULT 'client',
  `name` varchar(150) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `address` varchar(150) NOT NULL,
  `cv` varchar(100) NOT NULL,
  `company_name` varchar(150) NOT NULL,
  `job_title` varchar(150) NOT NULL,
  `notes` varchar(500) NOT NULL,
  `admin_notes` varchar(500) NOT NULL,
  `contacted` tinyint(1) NOT NULL DEFAULT '0',
  `shortlisted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `join_requests`
--

INSERT INTO `join_requests` (`id`, `join_as`, `name`, `mobile`, `email`, `address`, `cv`, `company_name`, `job_title`, `notes`, `admin_notes`, `contacted`, `shortlisted`, `created_at`, `updated_at`) VALUES
(1, 'accountant', 'fdfdsf', '4324324', 'fdsfsdf@dsfdsf.fdsfds', '', '', '', '', '', '', 0, 0, '2019-11-13 16:00:42', '2019-11-13 16:00:42'),
(2, 'client', 'fgdsfdsfd', 'frt454354354', 'marwan.nabil.mohamed@gmail.com', '', '', 'abc co.', 'developer', 'fdsfds fds \r\nfds \r\nfdsfdsfds', '', 0, 0, '2019-11-14 15:32:44', '2019-11-14 15:32:44'),
(3, 'client', 'fgdsfdsfd', 'frt454354354', 'marwan.nabil.mohamed@gmail.com', '', '', 'abc co.', 'developer', 'fdsfds fds \r\nfds \r\nfdsfdsfds', '', 0, 0, '2019-11-14 15:33:47', '2019-11-14 15:33:47'),
(4, 'accountant', 'lkfdglkfdj', '98573495847', 'lkjfdslfkjdslkffds@dfsfds.fsd', '', '', '', 'lfdjslfj vfd lkj', 'vfgf', '', 0, 0, '2019-11-15 11:42:37', '2019-11-15 11:42:37'),
(5, 'accountant', 'fdfdfd', 'fsdfds', 'dsfdsfdfds@fdsfdsfd', '', '', '', 'dsadsad', '', '', 0, 0, '2019-12-01 14:05:17', '2019-12-01 14:05:17'),
(6, 'accountant', 'fdsfds', '423324', 'fdsfdsfdsfds@mail.com', '', '', '', 'rerew', 'rewrew', '', 0, 0, '2019-12-03 15:39:02', '2019-12-03 15:39:02'),
(7, '3rdparty', 'fdsfds', '4324324', 'author@revapp.com', '', '', '', 'fdsfdsf', 'sdfdsf', '', 0, 0, '2019-12-03 15:43:19', '2019-12-03 15:43:19');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `section` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `option_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `option_val` text COLLATE utf8_unicode_ci NOT NULL,
  `icon` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `section`, `option_key`, `option_val`, `icon`, `created_at`, `updated_at`) VALUES
(11, 'site', 'website_title', 'McLedger', '', NULL, '2018-03-06 19:17:14'),
(12, 'site', 'copyrights', 'All rights are reserved 2020', '', NULL, '2018-03-26 15:02:59'),
(13, 'mail', 'email_from', 'info@mcledger.co', '', NULL, '2018-11-05 03:14:27'),
(14, 'mail', 'email_to', 'info@mcledger.co', '', NULL, '2018-11-05 03:14:27'),
(15, 'mail', 'email_name', 'McLedger', '', NULL, '2018-11-05 03:14:27'),
(16, 'awards', 'enable_registration', '0', '', NULL, NULL),
(17, 'social', 'facebook', 'https://www.facebook.com/mcledger', '', NULL, '2018-11-27 18:47:36'),
(18, 'social', 'Twitter', 'https://twitter.com/mcledger', '', NULL, '2018-11-05 03:14:27'),
(19, 'social', 'youtube', '', '', NULL, '2018-03-06 20:12:47'),
(20, 'social', 'instagram', '', '', NULL, '2017-10-10 09:33:07'),
(21, 'social', 'google-plus', '', '', NULL, NULL),
(22, 'social', 'flickr', '', '', NULL, NULL),
(23, 'social', 'whatsapp', '', '', NULL, NULL),
(24, 'social', 'rss', '', '', NULL, NULL),
(25, 'contact', 'Address', 'Egypt', '', NULL, '2017-06-07 11:35:39'),
(26, 'contact', 'Phone', '', '', NULL, '2018-11-27 18:47:36'),
(27, 'contact', 'Mobile', '', '', NULL, '2018-11-27 18:47:36'),
(28, 'contact', 'Fax', '0', '', NULL, '2018-11-27 18:47:36'),
(29, 'contact', 'Email', 'info@mcledger.co', '', NULL, '2018-11-05 03:14:27'),
(30, 'contact', 'Skype', '', '', NULL, NULL),
(31, 'contact', 'WhatsApp', '', '', NULL, '2017-10-11 09:18:52'),
(32, 'contact', 'Map', '29.950679, 30.944023', '', NULL, '2018-11-27 19:47:10'),
(33, 'meta', 'description_home', '', '', NULL, NULL),
(34, 'meta', 'keywords_home', '', '', NULL, NULL),
(35, 'meta', 'description_contact', '', '', NULL, NULL),
(36, 'meta', 'keywords_contact', '', '', NULL, NULL),
(37, 'social', 'google', '', '', NULL, '2018-03-06 20:12:47'),
(38, 'social', 'linkedin', 'https://www.linkedin.com/company/mcledger', '', NULL, '2018-11-05 03:14:27'),
(39, 'contact', 'CustomerService', '', '', NULL, '2018-11-27 18:47:36'),
(44, 'contact', 'MapiFrame', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d791.6988679841066!2d30.94460892151133!3d29.950680243005255!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjnCsDU3JzAyLjQiTiAzMMKwNTYnMzguNSJF!5e1!3m2!1sar!2seg!4v1543324059129\" width=\"100%\" height=\"450\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>', '', NULL, '2018-11-29 15:02:20'),
(45, 'contact', 'MapiFrameHome', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d791.6988679841066!2d30.94460892151133!3d29.950680243005255!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjnCsDU3JzAyLjQiTiAzMMKwNTYnMzguNSJF!5e1!3m2!1sar!2seg!4v1543324059129\" width=\"100%\" height=\"450\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>', '', NULL, '2018-11-29 15:02:20'),
(46, 'site', 'logo', '2018/11/1543049802.png', '', NULL, '2018-11-24 14:56:42');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `unsubscribed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `name`, `email`, `phone`, `unsubscribed`, `created_at`, `updated_at`) VALUES
(4, 'fdsfdsfdsfds', 'fdsfdsfdsfds@mail.com', '', 0, '2019-12-10 06:30:04', '2019-12-10 06:30:04');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `admin`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Marwan', 'marwan.nabil.mohamed@gmail.com', 1, NULL, '$2y$10$Dcfaa0lXZuXUEE5jL/JouuddF22IulZjpjfyi1nyr3RjdG2Aub6RK', NULL, '2019-11-07 13:32:13', '2019-11-07 13:32:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_authors`
--
ALTER TABLE `blog_authors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_categories`
--
ALTER TABLE `blog_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_comments`
--
ALTER TABLE `blog_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emails`
--
ALTER TABLE `emails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emails_bulk`
--
ALTER TABLE `emails_bulk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiries`
--
ALTER TABLE `enquiries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiry_reply`
--
ALTER TABLE `enquiry_reply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `join_requests`
--
ALTER TABLE `join_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `blog_authors`
--
ALTER TABLE `blog_authors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blog_categories`
--
ALTER TABLE `blog_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `blog_comments`
--
ALTER TABLE `blog_comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `emails`
--
ALTER TABLE `emails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `emails_bulk`
--
ALTER TABLE `emails_bulk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `enquiries`
--
ALTER TABLE `enquiries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `enquiry_reply`
--
ALTER TABLE `enquiry_reply`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `join_requests`
--
ALTER TABLE `join_requests`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
