-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 16, 2020 at 11:23 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.2.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mcledger_website`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` smallint(5) UNSIGNED NOT NULL,
  `author_id` smallint(5) UNSIGNED NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `details` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `banner` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pdf_file` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `pdf_file_title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `tags` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_desc` text COLLATE utf8_unicode_ci NOT NULL,
  `meta_keywords` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `sort` mediumint(8) UNSIGNED NOT NULL,
  `views` mediumint(8) UNSIGNED NOT NULL,
  `likes` smallint(5) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `category_id`, `author_id`, `slug`, `title`, `details`, `image`, `banner`, `pdf_file`, `pdf_file_title`, `tags`, `meta_desc`, `meta_keywords`, `active`, `featured`, `sort`, `views`, `likes`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 'all-you-need-to-know-about-fta-audit', 'All You Need To Know About FTA Audit', '<h1 style=\"text-align:center\"><strong>All You Need To Know About FTA Audit</strong></h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>The UAE government has already implemented VAT on the supply of taxable goods and services starting from January 01, 2018. The companies that are required to pay taxes can be audited by the Federal Tax Authority (FTA) to determine their tax compliance.</strong></h4>\r\n\r\n<h2>&nbsp;</h2>\r\n\r\n<h2 style=\"text-align:center\"><img alt=\"\" class=\"aligncenter\" src=\"https://mcledger.co/wp-content/uploads/2019/07/for-linked-link-on-facebook-700x368.png\" style=\"height:368px; width:700px\" /></h2>\r\n\r\n<h4>&nbsp;</h4>\r\n\r\n<p><strong>Reading time: 5 minutes</strong> &nbsp;</p>\r\n\r\n<h3><strong>What is Tax FTA Audit?</strong></h3>\r\n\r\n<p>A tax audit is a government&rsquo;s assessment of a company about their responsibility as a taxable entity. This kind of audit is conducted by the FTA to ensure that every liability is paid and every tax due is collected and given to the government within the timeframe given. The government also assesses whether the companies are following certain responsibilities that apply to their business as per the tax laws (VAT Law, Excise Tax Law, etc.). &nbsp;</p>\r\n\r\n<h3><strong>Detailed procedure</strong></h3>\r\n\r\n<p>The FTA will check the returns and other details. There may not be a specific reason for the FTA to conduct an audit of a company. They can conduct it based on any reason or whenever they want. A notice will be issued to the company at least five days before the scheduled audit date. It will contain details such as the audit schedule, place, involved parties, reason (if anything particular), etc. The auditor/s and the company will meet at the scheduled place at the scheduled time and the process will begin. The auditor may ask for business records, in original and/or copies, and take samples of goods and other assets as available at the place at the time. The tax audit is required to be conducted during the official FTA working hours unless the Director-General decides to conduct the audit of business outside regular hours, in an exceptional case. The company subject to tax audit along with its legal representatives and tax agents are required to provide full assistance to the auditors for performing their task. If anything suspicious is found in the result of the audit that might impact the tax return, the authority may order a re-audit for further analysis. The audited person has the right to ask for the notification copy and related documents and be present during the auditing procedures that are conducted outside of the official places. It is the job of the FTA to review and verify the tax declarations of the tax-registered businesses. Business owners should expect FTA to inspect them in the future as part of a practice to ensure that the tax regime is working properly and being complied with by the eligible people. &nbsp;</p>\r\n\r\n<h3><strong>What can you do to be prepared for the audit?</strong></h3>\r\n\r\n<p>McLedger (formerly known as PicWPost) can help you be organized so that when your company is requested for an audit from FTA, you are all set up to face the tax audit without worrying about it. The list below shows the kinds of review that can be done to prepare you for an upcoming audit:</p>\r\n\r\n<h4><strong>Review of the system</strong></h4>\r\n\r\n<p>Since the tax has been announced to commence in the UAE on the first day of 2018, companies have ensured that every department is ready to face a new era. One of the most important items to be updated is the accounting software. The same should comply with the laws regarding <a href=\"https://mcledger.co/vat-in-the-uae/\">VAT accounting</a>. A review of the systems will ensure that there is no inconsistency with the recorded transactions.</p>\r\n\r\n<h4><strong>Review of calculations tax</strong></h4>\r\n\r\n<p>Companies must ensure that they are complying with the laws by checking that the calculation of both output and input taxes are correct. As a basic rule, the tax rate is 5% only. Any goods or services that fall under zero-rated and exempted tax should be treated as it is with documents for support.</p>\r\n\r\n<h4><strong>Review of VAT returns</strong></h4>\r\n\r\n<p>McLedger will review the VAT returns that need to be filed by the companies to ensure that returns will be prepared perfectly, values properly recorded in the right boxes, and the needed information is filled in. We make sure that it is filed within the timeframe provided by the FTA.</p>\r\n\r\n<h4><strong>Review of payment of tax due</strong></h4>\r\n\r\n<p>The correct amount of tax due should be paid on or before the due date. We will ensure that you are not drawing any negative attention from the FTA by missing the deadline for tax payment to the government. &nbsp;</p>\r\n\r\n<h4><strong>What is FTA Audit File (FAF)?</strong></h4>\r\n\r\n<p>Once the tax audit is initiated, the concerned business is required to produce all the information in a prescribed manner known as the Audit file. The format of the Audit file will be in FAF prescribed format in which all the information as required, needs to be submitted by the businesses. The FTA expects that the tax accounting software used by the business should be able to generate the Audit file in FAF format so that the businesses find it easier to respond promptly to FTA&#39;s requests. Unlike the VAT return, which is a summary level return, meaning only the consolidated details of sales, purchase, input VAT, output VAT, etc. are declared, the audit file, designed in FAF format, needs to be produced at invoice level. The format of the FTA audit file should be in &#39;comma separated value&#39;(.csv) and should include details mentioned below:</p>\r\n\r\n<h4><strong>Company Information</strong></h4>\r\n\r\n<p>The FAF file should include the following details of the company, as applicable.</p>\r\n\r\n<ol>\r\n	<li>Taxable Person Name (English)</li>\r\n	<li>Taxable Person Name (Arabic)</li>\r\n	<li>TRN Tax (Registration Number)</li>\r\n	<li>Tax Agency Name</li>\r\n	<li>TAN (Tax Agency Number)</li>\r\n	<li>Tax Agent Name</li>\r\n	<li>TAAN (Tax Agent Approval Number)</li>\r\n</ol>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h4><strong>Supplier and customer details</strong></h4>\r\n\r\n<p>The location of the customer and supplier i.e. the country or the Emirate (in case country is UAE) along with TRN, if applicable, should be provided. Also, you may need to assign the tax codes, like ZR for Zero-rated supplies, to identify the nature of supply. &nbsp;</p>\r\n\r\n<h4><strong>Transactions details</strong></h4>\r\n\r\n<p>In the FAF file, you need to report the details at each invoice level. The details such as invoice number, invoice date, invoice value, VAT amount, etc. need to be captured in the audit file. The following are the transaction details you need to capture in the FTA Audit File (FAF).</p>\r\n\r\n<ul>\r\n	<li>Purchase Invoices / Imports / Credit Notes/</li>\r\n	<li>Sales Invoices / Credit Note</li>\r\n	<li>Invoice No.</li>\r\n	<li>Document number</li>\r\n	<li>Permit No. - If available</li>\r\n	<li>Invoice Date</li>\r\n	<li>Transaction Date</li>\r\n	<li>Transaction ID</li>\r\n	<li>Any reference ID identifying the transaction</li>\r\n	<li>Line No. - The line number of the invoice etc. (in case of multiple items in invoice etc.)</li>\r\n	<li>Debit and Credit Amount - In Actual Currency and Converted to AED</li>\r\n	<li>VAT Amount - In Actual Currency and Converted to AED</li>\r\n</ul>\r\n\r\n<p>In case of payment transactions, you need to capture the payment date. Apart from the above-mentioned details, you also need to capture the description of goods and services along with the VAT code, details of adjustment like journal entry and comment stating rounding off is used if the values are rounded off. &nbsp;</p>\r\n\r\n<h4><strong>Essential advice:</strong></h4>\r\n\r\n<ol>\r\n	<li>Host to audit will likely be taxable person office, or as per FTA requirements.</li>\r\n	<li>Tax records, files, books of accounts and statements should be readily reachable.</li>\r\n	<li>Reconcile your revenue and purchases/expenses announced in VAT returns with actual books of accounts.</li>\r\n</ol>', NULL, NULL, '', '', '', 'UAE businesses that are required to pay taxes can be audited by Federal Tax Authority  to determine their tax compliance. Here\'s what you should know.', 'VAT, Audit, fta, federal tax authority, tax agents, Business owners, VAT returns, TRN, invoice, transaction, tax registration number, tax accounting software', 1, 0, 0, 1, 0, '2020-11-15 12:40:48', '2020-11-15 12:40:53'),
(2, 4, 1, 'new-vat-cash-refund-limit-for-tourists', 'New VAT Cash Refund Limit For Tourists', '<h1 style=\"text-align:center\"><strong>New VAT Cash Refund Limit For Tourists</strong></h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>The FTA has set daily maximum VAT cash refund limit at Dh7,000.</strong></h4>\r\n\r\n<p><img alt=\"\" class=\"aligncenter\" src=\"https://mcledger.co/wp-content/uploads/2019/09/New-VAT-Cash-Refund-limit-1.jpg\" style=\"height:698px; width:1200px\" /> &nbsp; <strong>Reading time: 1 minute</strong> &nbsp; The FTA Decision No. (1) of 2019 has been issued, which outlines the daily maximum limit for the VAT cash refund at Dh7,000. This limit has been set for tourists applying through the Tax Refunds for Tourists Scheme. &nbsp; Tax Refunds for Tourists Scheme came into effect in November 2018. The FTA asserted that efficiency, seamless procedures, speed, and accuracy in processing applications characterize this scheme. &nbsp; It&#39;s been stated that this new decision regarding the maximum amount a tourist can reclaim daily in cash aligns with UAE&#39;s strategy, which focuses on reducing the reliance on cash in financial transactions. This will enable benefits from advanced technological and digital infrastructure, which are essential for the development of the country&#39;s economy. This decision also follows the best practices by advanced economies. &nbsp; The FTA is committed to implementing the highest international standards across all its activities and services. This aligns with the UAE&#39;s vision to maintaining its competitiveness as the economy based on innovation and creativity, making it one of the best countries in the world by 2021. &nbsp; Although if you run your business here in the UAE, you can get all VAT related help from us! The main goal of McLedger is to ensure your financial health is in great shape while you focus on what you love most - your business and grow with the best insights in hand from industry experts with the least effort from your end. &nbsp; McLedger offers various packages at pocket-friendly prices to ensure you don&rsquo;t have to pay hefty cheques, save more, and grow more with your accountant in the app by your side. &nbsp; Learn all about McLedger and its unique features of how it can ease up your business financials in an instant by calling us on <strong>056 5224041</strong> now! &nbsp; &nbsp; <strong><em>The original article was published in Khaleej Times on July 8, 2019. You can find it <a href=\"https://www.khaleejtimes.com/business/vat-in-uae/uae-announces-daily-cash-refund-limit-of-dh7000-1\">here.</a></em></strong></p>', '2020/11/1605451375.jpg', NULL, '', '', '', 'FTA outlined daily maximum limit for VAT cash refund at Dh7,000 that is set for tourists applying via Tax Refunds for Tourists Scheme.', 'FTA, VAT, tax refund, transaction, business, UAE, federal tax authority, cash refund', 1, 0, 0, 0, 0, '2020-11-15 12:42:55', '2020-11-15 12:42:55'),
(3, 4, 1, 'vat-refunds-processed-via-official-website', 'VAT Refunds Processed Via Official Website', '<h1 style=\"text-align:center\">VAT Refunds Processed Via Official Website</h1>\r\n\r\n<h4 style=\"text-align:center\">Some bank users had been receiving emails from unidentified sources representing banks and financial institutions requesting personal data to help them declare their VAT refunds.</h4>\r\n\r\n<h4 style=\"text-align:center\">&nbsp;</h4>\r\n\r\n<p><img alt=\"\" class=\"aligncenter size-full wp-image-2745\" src=\"https://mcledger.co/wp-content/uploads/2019/10/Process-VAT-refunds-only-through-official-platforms.jpg\" /> &nbsp; <strong>Reading time: 1 minute</strong> &nbsp; It had been reported that some bank users had been receiving emails from unidentified sources representing banks and financial institutions requesting personal data to help them declare their Value Added Tax (VAT) refunds. The FTA emphasized that these are fraudulent messages and that it never asks people to disclose their data via e-mail, text, or over the phone. It reaffirmed that tax refunds are processed only through the authority&#39;s official website. &nbsp; The FTA defined that tax refund operations for legally eligible categories are conducted directly between the authority and the taxpayer, with the authority approaching registrants directly without any third-party interference. &nbsp; The authority also guaranteed that refunds are accomplished by availing the latest secure electronic systems available on the authority&rsquo;s website and that these systems meet the strict safety standards relating to financial transactions. It was also mentioned that tax refunds can only be made by using the registrant&rsquo;s bank&rsquo;s IBAN through its systems, which are electronically linked to the central bank. &nbsp; It was also highlighted that all transactions - registration, submitting tax returns, refunding tax for eligible candidates, etc. - can be completed with a few simple steps via the e-Services portal, available 24/7 on the FTA website: www.tax.gov.ae. &nbsp; &nbsp; &nbsp; <strong><em>The original article was published in Khaleej Times on September 10, 2019. You can find it <a href=\"https://www.khaleejtimes.com/business/vat-in-uae/uae-makes-new-vat-announcement-heres-how-it-affects-you\">here.</a></em></strong></p>', '2020/11/1605451422.jpg', NULL, '', '', '', 'The FTA defined that tax refund operations for legally eligible categories are conducted directly between the authority and the taxpayer.', 'VAT, fta, value added tax, transaction, tax refund, registration, tax return, federal tax authority', 1, 0, 0, 0, 0, '2020-11-15 12:43:42', '2020-11-15 12:43:42'),
(4, 2, 1, 'de-registration-vat-you-can-do', 'De-Registration: VAT You Can Do', '<h1 style=\"text-align: center;\">De-Registration: <em>VAT</em> You Can Do</h1>\r\n<h4 style=\"text-align: center;\"><strong>Can a business de-register? What are the circumstances under which de-registration may be considered?</strong></h4>\r\n&nbsp;\r\n\r\n<img class=\"size-full wp-image-2749 aligncenter\" src=\"https://mcledger.co/wp-content/uploads/2019/11/De-Registration-Vat-You-Can-Do.jpg\" alt=\"\" />\r\n\r\n&nbsp;\r\n\r\n<strong>Reading time: 2 minutes</strong>\r\n\r\n&nbsp;\r\n\r\nWondering if de-registration is a taxing job? Well, we are here to help! Let us explain <em>vat </em>we mean.\r\n\r\n&nbsp;\r\n<h4><strong>Let\'s go back to the start!</strong></h4>\r\n<a href=\"https://mcledger.co/vat-in-the-uae/\">Value Added Tax (VAT) is an indirect tax imposed on supplies of goods and services.</a> With the standard rate of 5%, businesses in the UAE are responsible for documenting income and cost.\r\n\r\nA business must register for VAT if they meet the mandatory threshold of AED 375,000, i.e. if the value of taxable supply exceeds this limit. A business can voluntarily choose to register for VAT if it meets the voluntary threshold of AED 187,500, i.e., if the value of taxable supply exceeds this limit.\r\n\r\n&nbsp;\r\n<h4><strong>What is a taxable supply?</strong></h4>\r\nA taxable supply is a supply of goods and services on which the tax can be levied.\r\n\r\nThere are benefits of having a TRN. If a business avails the TRN, it becomes a collection agent of the government. This is rewarding as the VAT on business expenses of any kind can be claimed.\r\n\r\n&nbsp;\r\n<h4><strong>But can you de-register?</strong></h4>\r\nDefinitely! A business can de-register under a few circumstances.\r\n<ol>\r\n 	<li>If a registrant stops making taxable supplies;</li>\r\n</ol>\r\n<ol start=\"2\">\r\n 	<li>If the business still makes taxable supplies, but its value in the past back-to-back 12 months is less than the voluntary threshold;</li>\r\n 	<li>If the business continues to make taxable supplies, but the value in the past continuous 12 months is less than the mandatory threshold, it can voluntarily apply for de-registration.</li>\r\n</ol>\r\nIn the first two cases, the person must apply for de-registration within 20 business days of the situation taking place. Administrative penalties will be imposed in case of failure to apply within the specified date.\r\n\r\nBusinesses face other situations where they consider canceling their VAT registration. We have listed a few cases where the companies choose to de-register.\r\n<ol>\r\n 	<li>Duplicate TRN\r\nThis is a situation where one company has different applications submitted and each one has a TRN issued. This requires the cancellation of one TRN.</li>\r\n 	<li>Company branch has a TRN\r\nIn this scenario, a company\'s branch has a separate TRN issued whereas the branch should have the main company\'s TRN.</li>\r\n 	<li>Meeting voluntary threshold\r\nIf a business meets the voluntary threshold and not the mandatory threshold, it has a choice not to have TRN.</li>\r\n 	<li>Canceling trade license</li>\r\n</ol>\r\nA business entity\'s TRN will be canceled if its trade license is canceled.\r\n\r\n&nbsp;\r\n<h4><strong>Wait, before you go...</strong></h4>\r\nNo person can de-register without having paid all the due taxes and penalties it owed during the period it was registered for VAT.\r\n\r\nHence, it is essential that a registrant satisfies the requirements by the Federal Tax Authority for canceling of VAT registration and it is important to be aware of this provision for them to timely utilize it.\r\n\r\nFor any help or inquiry regarding VAT, get in touch with us on <strong>056 522 4041</strong> or <strong>info@mcledger.co</strong>\r\n\r\n&nbsp;\r\n\r\n&nbsp;', '2020/11/1605451560.jpg', NULL, '', '', '', 'Can a business de-register? What are the circumstances under which de-registration may be considered?', 'VAT, Value Added Tax, indirect tax, TRN, VAT registration, Federal Tax Authority, tax registration authority', 1, 0, 0, 0, 0, '2020-11-15 12:46:00', '2020-11-15 12:46:00'),
(5, 3, 1, 'busting-7-myths-about-small-businesses', 'Busting 7 Myths About Small Businesses', '<h1 style=\"text-align:center\"><strong>Busting 7 Myths About Small Businesses</strong></h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>An entrepreneur has to face many misconception in life. What are some of them that are widely popular?</strong></h4>\r\n\r\n<p><strong><img alt=\"\" class=\"aligncenter\" src=\"https://mcledger.co/wp-content/uploads/2020/01/blog-700x394.png\" style=\"height:394px; width:700px\" /></strong> &nbsp;</p>\r\n\r\n<p style=\"text-align:left\"><strong>Reading time: 2 minutes</strong></p>\r\n\r\n<p>&nbsp; Whether you are an aspiring entrepreneur or you already run a business, you would have come across the following perceptions in your day-to-day life. Look at some myths that we have broken for you! &nbsp;</p>\r\n\r\n<h4><strong>1. Entrepreneurs are risk-takers</strong></h4>\r\n\r\n<p style=\"text-align:left\">While the popular culture portrays entrepreneurs as frequent risk-takers, the opposite is true most of the time. Entrepreneurs assess situations and decide if the risk is to be taken.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h4 style=\"text-align:left\"><strong>2. The idea is more important than the details</strong></h4>\r\n\r\n<p style=\"text-align:left\">Many a time, people believe that an amazing idea is far more important than the details of how to execute the idea. This is not true as the details of execution pave the way for the smooth running of the business.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h4 style=\"text-align:left\"><strong>3. Your business plan must be well formulated from day one</strong></h4>\r\n\r\n<p style=\"text-align:left\">Running a company is a journey and in the course of that, many changes may occur. The business plan should not be so rigid that the necessary changes cannot be accommodated. It should be flexible enough to mold the business as and when required.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h4 style=\"text-align:left\"><strong>4. Passion will get you to success</strong></h4>\r\n\r\n<p style=\"text-align:left\">Passion may impress people, but it is not enough to get a business running. What is important is to know how to channel emotions in the course of running your business.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h4 style=\"text-align:left\"><strong>5. You must work 24/7</strong></h4>\r\n\r\n<p style=\"text-align:left\">You may run your business along with your team, but being the decision-maker, you will have to come up with quick solutions when need be. Having said that, it is unhealthy to keep working continuously without taking a break.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h4 style=\"text-align:left\"><strong>6. Small businesses do not need to be registered</strong></h4>\r\n\r\n<p style=\"text-align:left\">This is one of the biggest myths out there. Registration of business has nothing to do with the size of your business. Large or small, and no matter what industry it belongs to, businesses need to be registered for proper operation.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h4 style=\"text-align:left\"><strong>7. Small businesses do not need accounting</strong></h4>\r\n\r\n<p style=\"text-align:left\"><a href=\"https://mcledger.co/smes-startups-accounting-in-the-uae/\">Accounting is necessary regardless of the size of your business.</a> Having a complete understanding of your financials through in-depth reports assists in making decisions. It helps you create a budget, understand your tax obligations, and see how much profit you made. Many businesses choose accounting service providers to handle their day-to-day bookkeeping completely.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p style=\"text-align:left\">But you know what? We understand the everyday struggles of entrepreneurs and our online bookkeeping services are designed to adapt to their needs.</p>\r\n\r\n<p style=\"text-align:left\">Whether you own a bakery or a salon, McLedger has got you covered! Get in touch with us on <strong>056 522 4041</strong> or <strong>info@mcledger.co</strong></p>\r\n\r\n<p>&nbsp; &nbsp;</p>\r\n\r\n<p style=\"text-align:left\">&nbsp;</p>', '2020/11/1605516246.png', NULL, '', '', '', 'Whether you are an aspiring entrepreneur or you already run a business, you\'d have come across some myths. Let\'s break some myths for you.', 'Small Businesses, entrepreneur, business plan, budget,accounting, bookkeeping, bookkeeping services', 1, 0, 0, 0, 0, '2020-11-16 06:44:06', '2020-11-16 06:44:06'),
(6, 3, 1, '6-problems-smes-face', '6 Problems SMEs Face', '<h1 style=\"text-align:center\"><strong>6 Problems SMEs Face</strong></h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>From lack of brand awareness to balancing growth and quality, there&rsquo;s a lot that a small business has to see in the starting. </strong><strong> </strong></h4>\r\n\r\n<p><img alt=\"\" class=\"aligncenter wp-image-2292\" src=\"https://mcledger.co/wp-content/uploads/2020/03/sme-probs.jpg\" style=\"height:664px; width:746px\" /> &nbsp;</p>\r\n\r\n<p style=\"text-align:left\"><strong>Reading time: 3 minutes</strong></p>\r\n\r\n<p>&nbsp; Did you know that SMEs comprise about 94% of all the businesses in UAE? Employing millions, this sector is one of the major contributors to the economy. But what goes on in the making of a business? Do they grow overnight? Or is their journey filled with hurdles and difficulties? No business has a perfect success story and most of them have to face certain issues. We highlight some of these problems below. &nbsp;</p>\r\n\r\n<h4><strong>1. Brand awareness</strong></h4>\r\n\r\n<p>Due to the availability of a lot of digital resources for gaining knowledge, people are more aware than ever about various products and services. This makes it difficult for most companies to build a potential client base since people do not get convinced that easily.There is a lot of competition in the market and spreading brand awareness requires a very strong strategy. &nbsp;</p>\r\n\r\n<h4><strong>2. Strong leadership</strong></h4>\r\n\r\n<p>A strong leader can make or break the team. The success of any team depends on the way the leader leads. A leader must have the ability to be flexible and change his way of leading by adapting to the needs of his team. He should know how to use the best qualities of his team to get the work done. He learns from experience and implements those lessons in his leadership. &nbsp;</p>\r\n\r\n<h4><strong>3. Client dependence</strong></h4>\r\n\r\n<p>Never rely on a single client for most of your revenue. It is important to widen your client base to grow your business and establish stability. If a single most paying client quits, it won&rsquo;t affect your business much. &nbsp;</p>\r\n\r\n<h4><strong>4. Finding the right employees</strong></h4>\r\n\r\n<p>Many small businesses face this issue. In their attempt to save costs, they compromise on the quality. They lose a chance to hire the right person. Placing people in the wrong department also affects their productivity and their skillset goes unutilized. A person who is not suitable for the job can be harmful to the running of the business. &nbsp;</p>\r\n\r\n<h4><strong>5. Money management</strong></h4>\r\n\r\n<p>Most businesses start with limited money and face the challenge of maintaining regular cash flow. Mostly, the invested money is expected to return through the payments that the business receives. With no savings and unpaid bills, money management is a nightmare that many businesses face initially. Most businesses use revenue management tools to keep track of payments and manage revenue related tasks with in-built automatic tax calculation. They keep you notified of any unpaid invoices and encourage continuous business dealings with customers. It&rsquo;s always better to get professional help to maintain your books of accounts. This task becomes very complex with the growth of the company. <a href=\"https://mcledger.co/smes-startups-accounting-in-the-uae/\">Hence, it&#39;s advisable for SMEs to give priority to their bookkeeping. </a> &nbsp;</p>\r\n\r\n<h4><strong>6. Balancing quality and growth</strong></h4>\r\n\r\n<p>Most businesses have to reach a middle ground when it comes to compromising their quality for their growth. Usually, it is not easy because business owners may go on a path of unhealthy inclination to progress. This hampers their quality to the point that they lose a vision of their product. &nbsp; &nbsp; There&rsquo;s more to it than meets the eye. Businesses do not achieve success overnight. There is no one way to hit the jackpot, but most businesses believe in the trial and error method to see what works for them. The key is to never see any problem as a failure, but a step towards your goals. &nbsp; Though the road to success may be difficult, we can help to make it smooth. With McLedger invoicing and complete bookkeeping services, we make sure you can easily judge your business&rsquo;s progress. Get in touch with us on <strong>056 522 4041</strong> or <strong>info@mcledger.co</strong> &nbsp;</p>', '2020/11/1605516615.jpg', NULL, '', '', '', 'SMEs comprise about 94% of all businesses in UAE. Employing millions, they are one of major contributors to economy. So what are the issues they face?', 'SMEs, SMEs in UAE, brand awareness, small business, Money management, revenue management, invoices, invoicing, bookkeeping', 1, 0, 0, 0, 0, '2020-11-16 06:45:02', '2020-11-16 06:50:15'),
(7, 2, 1, 'filing-of-vat-return-in-uae', 'Filing Of VAT Return In UAE', '<h1 style=\"text-align:center\"><strong>Filing of VAT Return in UAE</strong></h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>FTA provides a complete procedure on how to file VAT return.</strong></h4>\r\n\r\n<p>&nbsp; <img alt=\"\" class=\"aligncenter size-full wp-image-2741\" src=\"https://mcledger.co/wp-content/uploads/2020/03/Filing-of-VAT-Return-in-UAE.jpg\" /> &nbsp;</p>\r\n\r\n<p style=\"text-align:left\"><strong>Reading time: 3 minutes</strong></p>\r\n\r\n<p>&nbsp; <a href=\"https://mcledger.co/vat-in-the-uae/\">With the introduction of VAT in UAE from 2018, there has been a huge shift in the business dynamics in the country.</a> As it&#39;s widely known, there are various benefits of VAT implementation. The FTA provides a complete procedure on how to file for the VAT return. Businesses are required to file their VAT returns through the FTA portal online by manually entering the mandatory information in the VAT return form. We highlight some of the fields in the form and the kind of information that goes in there.</p>\r\n\r\n<h4><strong>Taxable person details</strong></h4>\r\n\r\n<p>The taxable person&rsquo;s details, including TRN, name, and address will be automatically populated and will not require you to enter it. In the case of Tax Agent, their details like TAAN and TAN along with their name will be entered accordingly as well.</p>\r\n\r\n<h4><strong>VAT return period</strong></h4>\r\n\r\n<p>The &lsquo;VAT Return Period&rsquo; for which you are currently filing, the Tax Year-end and VAT period reference number will be automatically entered. The Tax Year-end is important for businesses that are not able to recover all of their VAT and need to perform an input tax apportionment annual adjustment. The VAT return period reference number tells you which tax period you are completing within that tax year.</p>\r\n\r\n<h4><strong>VAT on sales and other outputs</strong></h4>\r\n\r\n<p>Here you will have to enter the amount relating to sales and other inputs, VAT amount, and adjustment. The details of standard-rated supplies, supplies subject to the reverse charge provisions, zero-rated supplies, exempt supplies, etc. should be entered in their respective boxes. The total of all the above details is automatically calculated and you see the total output tax due to the FTA and total adjustments applicable to that value, for the tax period.</p>\r\n\r\n<h4><strong>VAT on expenses and all other inputs</strong></h4>\r\n\r\n<p>Here, you will have to enter all amounts related to all expenses, recoverable VAT amount, and adjustment. You will also have to enter all expenses subject to the standard rate of VAT for which you would like to recover Input Tax. The total of all the values is calculated, representing the total value of VAT you are entitled to recover, as well as any adjustments made to those values.</p>\r\n\r\n<h4><strong>Net VAT Due</strong></h4>\r\n\r\n<p>This part will indicate your payable tax for the Tax Period. The total value of the Output Tax that is due for the Tax Period will be calculated based on the information provided by you. The total value of Input Tax that is recoverable for the Tax Period will be calculated based on the given information. This will be the sum of the VAT and Adjustments columns in the Inputs section. The total value of the recoverable tax for the period shows the total value of the input tax that is recoverable for the tax period. Payable tax for the period is the difference between total due tax for the period and the recoverable tax for the period.</p>\r\n\r\n<h4><strong>Additional reporting requirement</strong></h4>\r\n\r\n<p>This section is for those who have used and applied the provisions of the Profit Margin Scheme during this period and so it requires the provision of additional reporting only for specific taxable persons to whom it applies.</p>\r\n\r\n<h4><strong>Declaration and authorized signatory</strong></h4>\r\n\r\n<p>All of the Authorised Signatory information will be prepopulated based on the information that has already been provided upon the completion of your Taxable Person records. Once you have finished filling this form, you have to tick the box next to the declaration section. It is important to verify all the details before submitting the VAT Return form. Click the submit button once you are completely sure. After the successful filing of the VAT Return, a taxpayer will receive an e-mail from FTA confirming the submission of the VAT return form. &nbsp; <em>The above information is directly sourced from VAT Returns User Guide by FTA. You can find it <a href=\"https://tax.gov.ae/-/media/Files/EN/PDF/Guides/VAT-Returns-User-Guide.pdf\">here.</a></em></p>', '2020/11/1605516604.jpg', NULL, '', '', '', 'FTA provides complete procedure on how to file for VAT return. We highlight some fields in the form and the kind of information that goes in there.', 'VAT, Filing of VAT Return, file VAT return, fta, vat in uae, trn, tax agent, federal tax authority', 1, 0, 0, 0, 0, '2020-11-16 06:45:49', '2020-11-16 06:50:04'),
(8, 3, 1, '7-mistakes-that-entrepreneurs-make', '7 Mistakes That Entrepreneurs Make', '<h1 style=\"text-align:center\">7 Mistakes That Entrepreneurs Make</h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>What are some of the mistakes that entrepreneurs are prone to making? Can your passion cloud your judgment?</strong></h4>\r\n\r\n<p>&nbsp; <img alt=\"\" class=\"aligncenter size-full wp-image-2706\" src=\"https://mcledger.co/wp-content/uploads/2020/03/Mistakes-all-1.jpg\" /> &nbsp;</p>\r\n\r\n<p style=\"text-align:left\"><strong>Reading time: 2 minutes</strong></p>\r\n\r\n<p>&nbsp; Being an entrepreneur is one of the most difficult jobs out there. It requires great willpower and commitment to pursue the passion and make it successful. The sacrifices that come with it and the hard work one has to put in makes it extremely stressful, but also rewarding. One of the most important things is to understand the mistakes that many entrepreneurs make in today&rsquo;s market and to avoid them as much as possible. So, what do business owners steer clear of when they establish their startup? Let&#39;s find out! &nbsp;</p>\r\n\r\n<h4><strong>1. No accountability</strong></h4>\r\n\r\n<p>Every business should try to create some amount of accountability. The customers value your work if you show them that you value it too and give it a lot of importance. If you have committed something to your customer, make sure you fulfill it. Accountability forms an integral part of an organization that sustains it in the long run. &nbsp;</p>\r\n\r\n<h4><strong>2. Ignoring gut feeling</strong></h4>\r\n\r\n<p>Trusting your instinct is the most important thing you will ever do. Though you may use logic and facts to make a well-reasoned decision, your gut will tell you what to trust and follow. &nbsp;</p>\r\n\r\n<h4><strong>3. Over expecting </strong></h4>\r\n\r\n<p>It is common to strive for success in whatever you do. However, in doing so, you build expectations and plans that may prove to be unrealistic at times and may lead you and your team to failure. Be careful to set well thought out goals that do not overburden the organization in general and the individuals in particular. &nbsp;</p>\r\n\r\n<h4><strong>4. Not setting the right priorities </strong></h4>\r\n\r\n<p>It is advisable to invest in the right solutions that form pillars of your business - be it employing right <a href=\"https://mcledger.co/smes-startups-accounting-in-the-uae/\">accounting practices</a>, prioritizing on getting sales and building your brand, or hiring right people. As you would have spent a great amount of time creating and nurturing your idea, you should find ways to sustain it. &nbsp;</p>\r\n\r\n<h4><strong>5. Unorganized work</strong></h4>\r\n\r\n<p>As an entrepreneur, there would be a lot of work on your plate, most of which requires your complete focus. You must organize your tasks well so that you can give each work the undivided attention that it deserves. &nbsp;</p>\r\n\r\n<h4><strong>6. Not understanding the market</strong></h4>\r\n\r\n<p>What is that one factor that can break your business? Incorrect study of the market. Business gets severely affected if you have no idea of who your target audience is or if you do not asses the market demand precisely. &nbsp;</p>\r\n\r\n<h4><strong>7. Micromanaging </strong></h4>\r\n\r\n<p>Delegating work does more good than harm, increasing efficiency, and productivity. Most business owners try to do all the work on their own, which proves to be harmful in the long run. Know what your strengths are and focus on doing what you are best at. &nbsp; There&rsquo;s no foolproof way to achieve success. Although mistakes are one of the best teachers of life, some of them can be avoided. One can learn from the experiences of other entrepreneurs, which may be highly beneficial for running a business. &nbsp; At McLedger, we believe in providing assistance to entrepreneurs in the best possible way, ensuring you have the right tools to avoid any error and make the right financial decisions for your business. Whether you&#39;ve just started out or have been in business for quite some time, we can streamline your business accounting and take away all the hassle of bookkeeping-related work. Get in touch with us on <strong>056 522 4041</strong> or <strong>info@mcledger.co</strong></p>', '2020/11/1605516590.jpg', NULL, '', '', '', 'Entrepreneurship requires willpower & commitment to gain success. We discuss a few mistakes you should avoid when starting your business.', 'entrepreneur, business owners, accountability, micromanaging, target audience', 1, 0, 0, 0, 0, '2020-11-16 06:47:14', '2020-11-16 06:49:50'),
(9, 3, 1, 'covid-19-what-small-businesses-can-do', 'Covid-19: What Small Businesses Can Do', '<h1 style=\"text-align:center\">Covid-19: What Small Businesses Can Do</h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>Entrepreneurs are facing fears regarding the survival of their business during the Covid-19 crisis. What are some immediate steps that they can take?</strong></h4>\r\n\r\n<p>&nbsp; <img alt=\"\" class=\"aligncenter size-full wp-image-2702\" src=\"https://mcledger.co/wp-content/uploads/2020/04/How-Can-Businesses.jpg\" /> &nbsp; <strong>Reading time: 2 minutes</strong> &nbsp; With the spread of Covid-19, many <a href=\"https://mcledger.co/smes-startups-accounting-in-the-uae/\">small businesses</a> are scared of what their future is going to be. They are trying to figure out how to navigate through this crisis that has brought disruption to their business. While the situation is sending people into panic mode and affecting the market, there are still a few things that businesses can do. &nbsp;</p>\r\n\r\n<h4><strong><strong>1. Care for your employees</strong></strong></h4>\r\n\r\n<p>It&rsquo;s very important to have clear communication with your staff. Empathize with them and address all their concerns. It&rsquo;s time to help each other face the crisis and survive it. Employees are the biggest assets of the company. Help your team feel secure and safe by providing them will everything that will ensure that they are healthy and can function normally as a member of the community. &nbsp;</p>\r\n\r\n<h4><strong><strong>2. Remote working</strong></strong></h4>\r\n\r\n<p>As the lockdown has begun in many places, businesses should come up with creative ways of effectively working from home without risking the health of the employees. Make sure to set up all the necessary technologies needed to ensure the continuation of work. Check some remote working tips to see how you can build a work routine at home. &nbsp;</p>\r\n\r\n<h4><strong><strong>3. Have a crisis preparedness plan handy</strong></strong></h4>\r\n\r\n<p>This crisis has hit the world with unpredictability and made us realize that many companies did not invest in a plan for crisis earlier. They now see the need to have one in place. One of the things that a plan should include is how easily remote working can be implemented and how to handle meetings while being away from the office. Most service businesses may still be able to work in some way, but other businesses like caf&eacute;s and restaurants may be severely affected. These businesses need to have an alternative in place to ensure their survival. &nbsp;</p>\r\n\r\n<h4><strong><strong>4. Support your customers</strong></strong></h4>\r\n\r\n<p>A business is built on a community of customers. Try to support your customers in any way that you can. Be flexible in offering your services or products and make certain adjustments to accommodate their demand to fulfill the duty that comes with nurturing good relations with them. &nbsp; Our customers&rsquo; welfare is important to us. Being a remote working friendly platform, we ensure our clients&rsquo; business health is taken care of, especially in times like this. Our online bookkeeping service does not require our accountants and clients to meet as all the work is done through our app. We know that these moments may be creating a lot of confusion. It&rsquo;s time to gather strength to stand in the face of adversity. Try not to act out of stress or panic. The positive side to all of this is that we, as a community, are trying our best to protect ourselves and each other. Stay safe, people! &nbsp; &nbsp; &nbsp; &nbsp;</p>', '2020/11/1605516580.jpg', NULL, '', '', '', 'Entrepreneurs are facing fears regarding the survival of their business during the Covid-19 crisis. What are some immediate steps that they can take?', 'consequences of covid-19 pandemic, remote working, online bookkeeping and accounting', 1, 0, 0, 0, 0, '2020-11-16 06:47:51', '2020-11-16 06:49:40'),
(10, 3, 1, '6-accounting-myths-you-shouldnt-believe', '6 Accounting Myths You SHOULDN’T Believe', '<h1 style=\"text-align:center\">6 Accounting Myths You SHOULDN&rsquo;T Believe</h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>Are most accountants men? Does your business need accounting? Find out the answers now!</strong></h4>\r\n\r\n<p>&nbsp; <img alt=\"\" class=\"aligncenter size-full wp-image-2700\" src=\"https://mcledger.co/wp-content/uploads/2020/04/6-Accounting-Myths-That-You-SHOULDN’T-Believe.jpg\" /> &nbsp; <strong>Reading time: 2 minutes</strong> &nbsp; Have you comes across people who don&#39;t have much idea of what an accountant does? They look quite confused when they hear the word &lsquo;accounting.&#39; Somehow, the stereotypical image of accountants starts playing in their minds. The reality sounds very different to them when they hear your view of working in an accounting company. We break a few myths that people believe about accounting. &nbsp;</p>\r\n\r\n<h4><strong>1. Accounting = Maths</strong></h4>\r\n\r\n<p>Math is used in a lot of professions and of course, day to day life, but to say that accounting is about math is not true. Accounting is about analysis and research but in a very interesting way. For you, a number may just be a digit. For us, it&rsquo;s more than that. It&rsquo;s the story that the numbers tell, the decisions that depend on them. &nbsp;</p>\r\n\r\n<h4><strong>2. Accounting is not for small businesses or startups</strong></h4>\r\n\r\n<p><a href=\"https://mcledger.co/smes-startups-accounting-in-the-uae/\">Even if you have a small business, accounting is still very essential for you to know how your business is doing.</a> Accounting is not a one-time job. Your financials need to be taken care of all year long. All the records must be clear, especially when the tax season rolls in. &nbsp;</p>\r\n\r\n<h4><strong>3. I need accounting only during VAT filing </strong></h4>\r\n\r\n<p>Surely VAT is a busy season, but accounting is not a one-time job. FTA requires businesses to maintain all their records and documents, especially if they have to be presented in case of an audit. This means proper records of the entire year. In case any business fails to produce the required records, they may be penalized accordingly. &nbsp;</p>\r\n\r\n<h4><strong>4. Accounting is expensive </strong></h4>\r\n\r\n<p>Getting your accounting done is not an expensive affair, unlike what you would have heard. There are accounting service providers that do accounting for you at the rates that fit your budget. McLedger online accounting and bookkeeping services are priced to suit the needs of startups, micro, and small businesses, providing them with uncompromised quality to assist in their growth. Accounting is meant to help you see how your company functions financially and how you can take advantage of opportunities around you. The smooth running of business demands insights of accountants. We spend our time to understand your business and give you all the insights and advice you need on the most beneficial path for your business. &nbsp;</p>\r\n\r\n<h4><strong>5. Only men are in this field </strong></h4>\r\n\r\n<p>When you think of an accountant, you think of a man in suits with glasses. That&rsquo;s just in movies. Women comprise more than 60% of the workforce in the accounting industry, dominating men in this area. &nbsp;</p>\r\n\r\n<h4><strong>6. Accountants are boring and don&rsquo;t like to socialize</strong></h4>\r\n\r\n<p>Not true at all. We have to interact a lot with clients to understand their business well and explain to them our analysis. Our art is to rightly interpret your financial information so you can take healthy business decisions. &nbsp; At work, we engage in serious discussions, experience fun moments together, celebrate little things, and come up with unique ideas to give the best accounting experience to our clients! &nbsp;</p>', '2020/11/1605516523.jpg', NULL, '', '', '', 'What are some of the myths about accounting and accountants that the world has? Let\'s break a few.', 'accounting service, accounting, accountant, accounting company, small business, startup,vat filing, federal tax authority', 1, 0, 0, 0, 0, '2020-11-16 06:48:43', '2020-11-16 06:48:43'),
(11, 4, 1, 'fta-extends-excise-tax-return-deadline', 'FTA Extends Excise Tax Return Deadline', '<h1 style=\"text-align:center\">FTA Extends Excise Tax Return Deadline</h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>The FTA has sought to ease tax burdens for registrants.</strong></h4>\r\n\r\n<p>&nbsp; <img alt=\"\" class=\"aligncenter size-full wp-image-2698\" src=\"https://mcledger.co/wp-content/uploads/2020/04/FTA-Extends-Excise.jpg\" /> &nbsp; <strong>Reading time: 1 minute</strong> &nbsp; The UAE&#39;s Federal Tax Authority (FTA) has extended the Excise Tax return submission deadline for March and April 2020 to May 17, 2020, to help businesses impacted by Covid-19 and lockdown in the country. &nbsp; The FTA &quot;has decided to extend the tax period for businesses registered for Excise Tax, which commenced on March 1, 2020 for one month on an exceptional basis, to end on April 30, 2020. The tax period shall now cover the months of March 2020 and April 2020, allowing registered businesses sufficient time to fulfill their tax obligations before the deadline,&quot; it said in a notice released on Monday. It advised businesses to file two separate tax returns for March and April till the new deadline. &nbsp; &quot;The Authority appreciates the urgent and exceptional nature of these developments, which have coincided with deadlines for filing Excise Tax returns. The FTA has sought to ease tax burdens for registrants in these circumstances to allow them to fulfill their obligations, file their tax returns, and settle their payable taxes within the legal timeframes,&quot; it said in a notice sent to its clients on Monday. In addition to FTA, other government entities have also announced measures to support private sector overcome coronavirus challenges. &nbsp; <em>T<strong>he original article was published in Khaleej Times on April 14, 2020. You can find it <a href=\"https://www.khaleejtimes.com/excise-tax-returns-can-be-submitted-by-may-17\">here.</a></strong></em></p>', '2020/11/1605516561.jpg', NULL, '', '', '', 'The FTA has extended the Excise Tax return submission deadline for March and April 2020 to May 17, 2020.', 'Federal Tax Authority, uae covid 19, fta, tax return, businesses', 1, 0, 0, 0, 0, '2020-11-16 06:49:21', '2020-11-16 06:49:21');
INSERT INTO `blog` (`id`, `category_id`, `author_id`, `slug`, `title`, `details`, `image`, `banner`, `pdf_file`, `pdf_file_title`, `tags`, `meta_desc`, `meta_keywords`, `active`, `featured`, `sort`, `views`, `likes`, `created_at`, `updated_at`) VALUES
(12, 2, 1, 'how-is-vat-in-uae-affecting-you', 'How Is VAT In UAE Affecting You?', '<h1 style=\"text-align: center;\"><strong>How Is VAT In UAE Affecting You?</strong></h1>\r\n<h4 style=\"text-align: center;\"><strong>What is the impact of VAT? What are some of the benefits of VAT implementation? We give you the answers.</strong></h4>\r\n<img class=\"size-full wp-image-2696 aligncenter\" src=\"https://mcledger.co/wp-content/uploads/2020/04/vat-twitter.jpg\" alt=\"\" />\r\n\r\n<strong>Reading time: 2 minutes</strong>\r\n\r\n&nbsp;\r\n\r\nAs one of the main aims of <a href=\"https://mcledger.co/vat-in-the-uae/\">VAT introduction in UAE</a> has been to move towards more non-oil based revenue, it is interesting to see how it will continue to shape the country’s economy in the years to come.\r\n\r\nWith different sources of income coming up, the government can spend much more on providing the public with high-quality services.\r\n\r\nBut have you wondered how VAT may be beneficial to the country? Take a look!\r\n\r\n&nbsp;\r\n<h4><strong>1. Increased government funds</strong></h4>\r\nOne of the upsides to VAT is diversification of revenue base and increase in the funds of the government, which would help in creating a more stable economic condition and would have a positive effect on the businesses.\r\n\r\n&nbsp;\r\n<h4><strong>2. Better infrastructure</strong></h4>\r\nThe revenue would gradually lead to the stabilization of the economy and the improvement of infrastructure, making it easier to do business in the UAE.\r\n\r\n&nbsp;\r\n<h4><strong>3. A rise in business efficiency</strong></h4>\r\nMany businesses run more efficiently with VAT compliant accounting apps or software in place, replacing outdated accounting systems. The businesses can avail complete bookkeeping from these service providers at affordable rates.\r\n\r\n&nbsp;\r\n<h4><strong>4. New opportunities</strong></h4>\r\nVAT implementation opens up all the opportunities for the entrepreneurs who want to start advisory firms as the complexities of VAT systems can be explained by consultants specializing in this field. Most of the businesses are busy in their activities and would require someone to help them by adapting to and understanding their business.\r\n\r\n&nbsp;\r\n<h4><strong>5. Other benefits</strong></h4>\r\nIt’s been seen around the world that tax implementation comes with many non-financial benefits. One of them is improving the accountability of government as maintaining proper taxation records will lead to better and well-reasoned decisions.\r\n\r\n&nbsp;\r\n\r\nWe understand that businesses are still getting adjusted to the VAT laws. One of the things you can do to reduce any VAT related stress is to seek the advice of professionals who can guide you well. Our accountants are experts at providing the right consultation to businesses and have hands-on experience in taking care of all VAT-related responsibilities. To know what you can get with McLedger online accounting, get in touch with us at <strong>info@mcledger.co</strong> or call us on <strong>056 522 4041</strong>\r\n\r\n&nbsp;\r\n\r\n&nbsp;', '2020/11/1605516650.jpg', NULL, '', '', '', 'We look into the possibilities of how VAT implementation in the UAE will continue to shape the country’s economy in the years to come.', 'accountant, vat in uae, businesses, accounting, accounting system, bookkeeping, entrepreneur', 1, 0, 0, 0, 0, '2020-11-16 06:50:50', '2020-11-16 06:50:50'),
(13, 4, 1, 'fta-extends-vat-returns-deadline', 'FTA Extends VAT Returns Deadline', '<h1 style=\"text-align:center\"><strong>FTA Extends VAT Returns Deadline</strong></h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>This applies to the tax period ending on March 31, 2020, only.</strong></h4>\r\n\r\n<p>&nbsp; <img alt=\"\" class=\"aligncenter size-full wp-image-2694\" src=\"https://mcledger.co/wp-content/uploads/2020/04/FTA-Extends.jpg\" /> &nbsp; <strong>Reading time: 1 minute </strong> &nbsp; The FTA has extended the deadline for submitting VAT returns and the payment of due tax to May 28, 2020. This exception applies to VAT registrants who have monthly and quarterly tax periods ending on March 31, 2020. It does not apply to any other tax period. VAT registrants are to ensure that the data is accurate in their VAT returns and that the FTA receives the payable tax for the tax period ending March 31, 2020, by Thursday, May 28, 2020. They are to abide by all other tax obligations as usual. This step has been taken to support the VAT registrants and allow them to fulfill their tax obligations without facing any problems. The UAE has taken many precautionary measures to curb the spread of Covid-19. One of them is restricting the movements of people and vehicles in certain areas, which coincides with the deadline for filing VAT returns. Many businesses are affected due to this. However, these are necessary measures to safeguard public health. Among others, actions include a nationwide disinfection campaign, the shutdown of malls and markets, suspension of flights, remote working for the public and private sector, distance learning for schools and universities. &nbsp; &nbsp; <em>If your tax period is from January 1, 2020, to March 31, 2020, and you have any concerns or queries, kindly get in touch with us <strong>050-9965191</strong> and <strong>056-5016323</strong> </em> &nbsp; <strong><em>The original article was published in Khaleej Times on April 21, 2020. You can find it <a href=\"https://www.khaleejtimes.com/business/vat-in-uae/deadline-for-submitting-vat-returns-extended-in-uae\">here</a>.</em></strong></p>', '2020/11/1605516698.jpg', NULL, '', '', '', 'The FTA has extended the deadline for submitting VAT returns and the payment of due tax to May 28, 2020.', 'vat return, tax period, tax obligations, uae covid 19, vat registrant, payable tax, FTA, VAT, businesses', 1, 0, 0, 0, 0, '2020-11-16 06:51:38', '2020-11-16 06:51:38'),
(14, 4, 1, '100-initiatives-uae-against-covid-19', '100 Initiatives: UAE Against Covid-19', '<h1 style=\"text-align:center\">100 Initiatives: UAE Against Covid-19</h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>Multiple measures launched to combat the problems surfacing due to the lockdown.</strong></h4>\r\n\r\n<p>&nbsp; <img alt=\"\" class=\"aligncenter size-full wp-image-2692\" src=\"https://mcledger.co/wp-content/uploads/2020/05/100-Initiatives.jpg\" /> <strong>Reading time: 3 minutes</strong> &nbsp; The UAE has been proactive in managing the challenges arising from the Covid-19 pandemic. According to a survey conducted by the Federal Competitiveness and Statistics Authority, there have been more than 100 incentives and measures launched by the federal government, local governments, and the Central Bank of the UAE. &nbsp; Measures to deal with the economic setback following the lockdown include:</p>\r\n\r\n<ul>\r\n	<li>Dh256 billion capital and liquidity measures rolled out by the CBUAE. It consists of Dh50 billion in capital buffer relief, Dh50 billion in zero-cost funding support, Dh95 billion in liquidity buffer relief, and a Dh61 billion reduction of cash reserve requirements</li>\r\n	<li>Concessions and stimulus packages worth billions of dirham announced by the UAE Cabinet, governments of various emirates, ministries and free zones</li>\r\n	<li>Extension of residence permits expiring on March 1st, 2020 for a renewable period of three months without any additional fees upon renewal</li>\r\n	<li>The Ministry of Economy has slashed fees across 94 types of services provided to individuals, companies, and the business sector</li>\r\n	<li>Additional banking facilities to various economic sectors, SMEs enterprises, and individuals, as well as exemptions, postponing of dues and other related concessions</li>\r\n</ul>\r\n\r\n<p>&nbsp; Several incentives have been launched in Abu Dhabi:</p>\r\n\r\n<ul>\r\n	<li>Providing individuals and SMEs with immediate support and, reduction of financing costs</li>\r\n	<li>Banking incentives include a moratorium on payments of installments, interest on loans and credit cards for three months</li>\r\n	<li>Allowing the electronic payment of electricity and water bills, and the opportunity to pay school fees in installments without interest</li>\r\n</ul>\r\n\r\n<p>&nbsp; The following incentives have been launched for companies:</p>\r\n\r\n<ul>\r\n	<li>Allocation of Dh5 billion to support electricity and water companies</li>\r\n	<li>Dh3 billion towards an SME financing guarantee program</li>\r\n	<li>Dh1 billion for the establishment of the &quot;Market Maker Fund&quot;</li>\r\n	<li>Reduction of rental service fees by 50 percent for SMEs on transactions less than Dh5 million</li>\r\n	<li>Reducing fees and prices by 50 percent for accounts without balance</li>\r\n</ul>\r\n\r\n<p>&nbsp; Some other provisions include:</p>\r\n\r\n<ul>\r\n	<li>Three-month payment freeze on bad debts of citizens</li>\r\n	<li>Forbidding rental evictions and related executive procedures</li>\r\n	<li>Exemption of fees for renewing licenses for commercial activities</li>\r\n</ul>\r\n\r\n<p>&nbsp; The following measures have been introduced in Dubai:</p>\r\n\r\n<ul>\r\n	<li>Incentives worth Dh1.5 billion for three months to support individuals and the businesses</li>\r\n	<li>Delaying the repayment of loans for those without salaries for three months free of interest or fees</li>\r\n	<li>A five percent hike in financing value of residential properties for first-time buyers</li>\r\n	<li>Refund of application fees and fees imposed for the cancellation of travel tickets paid with credit and debit cards</li>\r\n	<li>Refund of cash withdrawal fees at ATMs</li>\r\n	<li>Injection of fresh capital into Emirates Airline</li>\r\n	<li>10 percent deduction in water and electricity bills for three months</li>\r\n	<li>A cut in insurance premiums by 50 percent</li>\r\n	<li>Postponing the payment of rent in free zones</li>\r\n</ul>\r\n\r\n<p>&nbsp; The incentives in Sharjah include:</p>\r\n\r\n<ul>\r\n	<li>Benefits for the tourism sector such as exempting hotels from municipality fees for three months</li>\r\n	<li>Discounted fees for exhibitions in 2020</li>\r\n	<li>50 percent discount for shops and commercial centers participating in marketing campaigns</li>\r\n	<li>50 percent rental reduction for three months for restaurants, currency exchanges, shops, banks, travel agencies, communication stores, and tourism promotion and car rental companies inside airports</li>\r\n</ul>\r\n\r\n<p>&nbsp; The governments of Ajman, Ras Al Khaimah, Umm Al Qaiwain, and Fujairah have also launched swift and effective initiatives including exemption from fees for certain government services and partial exemptions for other fees. &nbsp; <strong><em>The original article was published in Khaleej Times on April 21, 2020. You can find it <a href=\"https://www.khaleejtimes.com/business/local/over-100-incentives-launched-across-uae-to-support-economy\">here.</a></em></strong></p>', '2020/11/1605516934.jpg', NULL, '', '', '', 'Multiple measures launched by federal government, local governments, & the Central Bank of UAE to combat the problems surfacing due to the lockdown.', 'uae government incentives, SME, bank incentives, businesses, covid 19 uae, free zones', 1, 0, 0, 0, 0, '2020-11-16 06:55:34', '2020-11-16 06:55:34'),
(15, 1, 1, 'save-more-with-accounting-bookkeeping-app', 'Save More With Accounting & Bookkeeping App', '<h1 style=\"text-align:center\">Save More With Accounting &amp; Bookkeeping App</h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>How can you, as an entrepreneur, make the right decisions for your UAE startup and work towards healthy growth? Find out now.</strong></h4>\r\n\r\n<p>&nbsp; <img alt=\"\" class=\"aligncenter size-full wp-image-2710\" src=\"https://mcledger.co/wp-content/uploads/2020/05/00-02.jpg\" /> &nbsp; <strong>Reading time: 2 minutes</strong> &nbsp; It&#39;s a quite well-known fact that startups are on the rise in the UAE and the MENA region in general. The entrepreneurs of today have vast opportunities that they can utilize to nurture their innovation and impact the surrounding ecosystem. But how can they ensure that their startup is on the right track despite any hindrance that it may have to face? <a href=\"https://mcledger.co/mcledger-online-accounting-for-smes/\">Here are a few ways we can help enable your steady growth through the tools we provide.</a> &nbsp;</p>\r\n\r\n<h4><strong>1. Say yes to online accounting</strong></h4>\r\n\r\n<p>Want to work from home, but need to look after your accounts? There&rsquo;s absolutely no worry! Just open our app on your phone or web. Check the status of your FinDocs. See if your VAT report is ready and set for filing. You don&#39;t even have to learn how to use the app. We wanted to empower you, enable you to become independent, and ease the reliance on anyone. You can now invest time and resources in other areas of your startup. It&rsquo;s that simple. &nbsp;</p>\r\n\r\n<h4><strong>2. Work on the move</strong></h4>\r\n\r\n<p>Have an important meeting to attend, but also have to see if your customers have made payments? Say goodbye to files &amp; papers! Check the payment history &amp; track unpaid invoices on your way to the meeting. As you may know, manual invoicing is a costly affair that is also likely to include errors. You are likely to spend a lot of time &amp; money in it, which can be avoided by using an invoicing app that integrates with an accounting app to fast-track the accounting mechanism &amp; reduce efforts. That&#39;s possible with both the McLedger apps! &nbsp;</p>\r\n\r\n<h4><strong>3. Enhance profits </strong></h4>\r\n\r\n<p>Sitting at Starbucks &amp; wondering if your startup is heading in the right direction? Check the financial insights on the app instantly. All financial statements from different periods in one place. Let your team refer to them &amp; build strategies accordingly. With detailed analysis, you would surely know how to direct your focus on the most valuable &amp; profitable resources. We present the financial information in an easy-to-understand way so you can make quick decisions for your startup! &nbsp;</p>\r\n\r\n<h4><strong>4. Go paperless</strong></h4>\r\n\r\n<p>This is the digital era. You don&#39;t need paper &amp; printing resources when all reports, financial charts, &amp; details can be accessed &amp; saved digitally. You can even create and send tax invoices through the app! The days of searching lost receipts in the piles of paper are over. Your documents are archived for 5 years with our cloud storage! &nbsp;</p>\r\n\r\n<h4><strong>5. Do more with less</strong></h4>\r\n\r\n<p>Your accountants are in your app, giving you more time &amp; saving resources to invest in other areas of your startup. You get the app, the accountants in the app, the accounting through the app. That&rsquo;s how convenient life is with us! &nbsp; Come on board with us and steer clear of any financial epidemic! It&#39;s time to take your startup to new heights. Call us now at <strong>+971 56 522 4041</strong> or <strong>+971 56 501 6323 </strong> &nbsp;</p>', '2020/11/1605517002.jpg', NULL, '', '', '', 'How can you make the right decisions for your startup & work towards healthy growth? We tell you how our accounting solution is perfect for you.', 'uae startup, accounting, entrepreneur, vat, invoicing, profit, financial statement, accountant', 1, 0, 0, 0, 0, '2020-11-16 06:56:42', '2020-11-16 06:56:42'),
(16, 4, 1, 'dff-report-supporting-startups-for-economy', 'DFF Report: Supporting Startups For Economy', '<h1 style=\"text-align:center\">DFF Report: Supporting Startups For Economy</h1>\r\n\r\n<h4 style=\"text-align:center\"><strong>The report highlights many suggestions to sustain the startup sector in the UAE.</strong></h4>\r\n\r\n<p><img alt=\"\" class=\"aligncenter size-full wp-image-2690\" src=\"https://mcledger.co/wp-content/uploads/2020/05/DFF-report.jpg\" /> &nbsp; <strong>Reading time: 2 minutes</strong> &nbsp; The Dubai Future Foundation was founded to play an important role in transforming the future. The foundation strives to establish Dubai as the major leading hub of the future. It attempts to achieve this by imagining, inspiring, and inventing Dubai&#39;s future, especially in collaboration with the government and private entities. &nbsp; It has offered many plans to improve the innovation ecosystem in the UAE and the region. These include, among others, reducing or delaying office costs, utility bills, and license fees, as well as offering open grants, providing loans and flexible financing. &nbsp; It came up with a report titled &#39;Life After Covid-19: Innovation and Entrepreneurship&#39;, that has suggested the concept of funding salaries for a short period, reducing living costs, increasing mobility across visas and free zones for highly skilled talents and supporting temporary employment as means to support the startup sector. &nbsp; As per this report, the startups in the UAE will face many challenges due to the pandemic. UAE is one of the countries that are ready to deal with changes in the innovation and entrepreneurial sector. Small startups constitute about 50 percent of companies registered in Dubai and represent about 47 percent of the UAE&#39;s annual GDP. &nbsp; The report highlights methods to combat the effects of Covid-19 on startups and their growth opportunities. It recommends motivational packages and incentive schemes as a means to support the startup sector and economic development in the country. &nbsp; The report also highlights the incentives that the UAE has taken up to support the entrepreneurs and startups. SMEs play a crucial role in the economic development of the nation. The UAE takes great steps in promoting the innovation and sustainability of the entrepreneurs. As the global pandemic has revealed the importance of flexibility and adaptability to different conditions, the UAE is trying to increase the reliance on remote working. It has aided in issuing commercial licenses and visas. The UAE has also kept up with the changes in the technology and innovation sector. It has accomplished to update regulations in various economic sectors by following global developments. &nbsp; According to the report, government support for startups will re-establish the sector once the pandemic fades. It asserts that the innovation sector will act as a catalyst in supporting the growth of startups and entrepreneurs in the UAE by enhancing financing and providing low-cost financial services. &nbsp; &nbsp; <strong><em>The original article was published in Khaleej Times on April 26, 2020. You can find it <a href=\"https://www.khaleejtimes.com/business/local/empowering-startups-critical-for-future-of-sustainable-economy-dff-report\">here.</a></em></strong></p>', '2020/11/1605517047.jpg', NULL, '', '', '', 'DFF report highlights many suggestions to sustain the startup sector in the UAE.', 'covid-19, innovation, entrepreneur, startup, SMEs, free zones', 1, 0, 0, 0, 0, '2020-11-16 06:57:27', '2020-11-16 06:57:27');

-- --------------------------------------------------------

--
-- Table structure for table `blog_authors`
--

CREATE TABLE `blog_authors` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `image` varchar(60) DEFAULT NULL,
  `details` text,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blog_authors`
--

INSERT INTO `blog_authors` (`id`, `slug`, `name`, `image`, `details`, `active`, `created_at`, `updated_at`) VALUES
(1, 'editor', 'Editor', NULL, '', 1, '2020-11-15 14:29:32', '2020-11-15 14:29:32');

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

CREATE TABLE `blog_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog_categories`
--

INSERT INTO `blog_categories` (`id`, `slug`, `title`, `active`, `created_at`, `updated_at`) VALUES
(1, 'mcledger', 'McLedger', 1, '2020-11-15 12:27:54', '2020-11-15 12:27:54'),
(2, 'vat', 'VAT', 1, '2020-11-15 12:28:02', '2020-11-15 12:28:02'),
(3, 'accounting-bookkeeping', 'Accounting & Bookkeeping', 1, '2020-11-15 12:28:12', '2020-11-15 12:28:12'),
(4, 'industry-news', 'Industry News', 1, '2020-11-15 12:28:19', '2020-11-15 12:28:19');

-- --------------------------------------------------------

--
-- Table structure for table `blog_comments`
--

CREATE TABLE `blog_comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `record_id` int(10) UNSIGNED NOT NULL,
  `model` varchar(30) NOT NULL,
  `name` varchar(80) NOT NULL,
  `email` varchar(60) NOT NULL,
  `comment` text NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blog_comments`
--

INSERT INTO `blog_comments` (`id`, `record_id`, `model`, `name`, `email`, `comment`, `active`, `created_at`, `updated_at`) VALUES
(1, 35, 'Blog', 'Marwan', 'marwan.nabil.mohamed@gmail.com', 'Yes, looks great', 1, '2019-12-10 13:34:38', '2019-12-10 13:37:08');

-- --------------------------------------------------------

--
-- Table structure for table `emails`
--

CREATE TABLE `emails` (
  `id` int(11) NOT NULL,
  `email_template_id` mediumint(8) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `subject` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `goto_inbox` tinyint(1) NOT NULL DEFAULT '0',
  `goto_email` tinyint(1) NOT NULL DEFAULT '0',
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `emails_bulk`
--

CREATE TABLE `emails_bulk` (
  `id` int(11) NOT NULL,
  `active_status` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `award_branches` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `goto_inbox` tinyint(1) NOT NULL,
  `goto_email` int(11) NOT NULL,
  `candidates_received` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'serialized object',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `enquiries`
--

CREATE TABLE `enquiries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) NOT NULL,
  `phone` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(500) NOT NULL,
  `replied` tinyint(1) NOT NULL DEFAULT '0',
  `from` varchar(30) NOT NULL,
  `to` varchar(30) NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `enquiries`
--

INSERT INTO `enquiries` (`id`, `name`, `phone`, `email`, `subject`, `message`, `replied`, `from`, `to`, `read`, `created_at`, `updated_at`) VALUES
(1, 'fdsfdsfds', '432432432', 'dsdsadsadsa@mmm.com', '', 'fdsfds fdsfds', 0, '', '', 0, '2019-11-14 22:04:00', '2019-11-14 22:04:00');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_reply`
--

CREATE TABLE `enquiry_reply` (
  `id` int(11) NOT NULL,
  `enquiry_id` int(10) UNSIGNED NOT NULL,
  `subject` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `admin_id` mediumint(8) UNSIGNED NOT NULL,
  `goto_email` tinyint(1) NOT NULL,
  `goto_inbox` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `join_requests`
--

CREATE TABLE `join_requests` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `join_as` enum('accountant','client','checker','3rdparty') NOT NULL DEFAULT 'client',
  `name` varchar(150) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `address` varchar(150) NOT NULL,
  `cv` varchar(100) NOT NULL,
  `company_name` varchar(150) NOT NULL,
  `job_title` varchar(150) NOT NULL,
  `notes` varchar(500) NOT NULL,
  `admin_notes` varchar(500) NOT NULL,
  `contacted` tinyint(1) NOT NULL DEFAULT '0',
  `shortlisted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `join_requests`
--

INSERT INTO `join_requests` (`id`, `join_as`, `name`, `mobile`, `email`, `address`, `cv`, `company_name`, `job_title`, `notes`, `admin_notes`, `contacted`, `shortlisted`, `created_at`, `updated_at`) VALUES
(1, 'accountant', 'fdfdsf', '4324324', 'fdsfsdf@dsfdsf.fdsfds', '', '', '', '', '', '', 0, 0, '2019-11-13 16:00:42', '2019-11-13 16:00:42'),
(2, 'client', 'fgdsfdsfd', 'frt454354354', 'marwan.nabil.mohamed@gmail.com', '', '', 'abc co.', 'developer', 'fdsfds fds \r\nfds \r\nfdsfdsfds', '', 0, 0, '2019-11-14 15:32:44', '2019-11-14 15:32:44'),
(3, 'client', 'fgdsfdsfd', 'frt454354354', 'marwan.nabil.mohamed@gmail.com', '', '', 'abc co.', 'developer', 'fdsfds fds \r\nfds \r\nfdsfdsfds', '', 0, 0, '2019-11-14 15:33:47', '2019-11-14 15:33:47'),
(4, 'accountant', 'lkfdglkfdj', '98573495847', 'lkjfdslfkjdslkffds@dfsfds.fsd', '', '', '', 'lfdjslfj vfd lkj', 'vfgf', '', 0, 0, '2019-11-15 11:42:37', '2019-11-15 11:42:37'),
(5, 'accountant', 'fdfdfd', 'fsdfds', 'dsfdsfdfds@fdsfdsfd', '', '', '', 'dsadsad', '', '', 0, 0, '2019-12-01 14:05:17', '2019-12-01 14:05:17'),
(6, 'accountant', 'fdsfds', '423324', 'fdsfdsfdsfds@mail.com', '', '', '', 'rerew', 'rewrew', '', 0, 0, '2019-12-03 15:39:02', '2019-12-03 15:39:02'),
(7, '3rdparty', 'fdsfds', '4324324', 'author@revapp.com', '', '', '', 'fdsfdsf', 'sdfdsf', '', 0, 0, '2019-12-03 15:43:19', '2019-12-03 15:43:19');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `section` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `option_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `option_val` text COLLATE utf8_unicode_ci NOT NULL,
  `icon` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `section`, `option_key`, `option_val`, `icon`, `created_at`, `updated_at`) VALUES
(11, 'site', 'website_title', 'McLedger', '', NULL, '2018-03-06 19:17:14'),
(12, 'site', 'copyrights', 'All rights are reserved 2020', '', NULL, '2018-03-26 15:02:59'),
(13, 'mail', 'email_from', 'info@mcledger.co', '', NULL, '2018-11-05 03:14:27'),
(14, 'mail', 'email_to', 'info@mcledger.co', '', NULL, '2018-11-05 03:14:27'),
(15, 'mail', 'email_name', 'McLedger', '', NULL, '2018-11-05 03:14:27'),
(16, 'awards', 'enable_registration', '0', '', NULL, NULL),
(17, 'social', 'facebook', 'https://www.facebook.com/mcledger', '', NULL, '2018-11-27 18:47:36'),
(18, 'social', 'Twitter', 'https://twitter.com/mcledger', '', NULL, '2018-11-05 03:14:27'),
(19, 'social', 'youtube', '', '', NULL, '2018-03-06 20:12:47'),
(20, 'social', 'instagram', '', '', NULL, '2017-10-10 09:33:07'),
(21, 'social', 'google-plus', '', '', NULL, NULL),
(22, 'social', 'flickr', '', '', NULL, NULL),
(23, 'social', 'whatsapp', '', '', NULL, NULL),
(24, 'social', 'rss', '', '', NULL, NULL),
(25, 'contact', 'Address', 'Egypt', '', NULL, '2017-06-07 11:35:39'),
(26, 'contact', 'Phone', '', '', NULL, '2018-11-27 18:47:36'),
(27, 'contact', 'Mobile', '', '', NULL, '2018-11-27 18:47:36'),
(28, 'contact', 'Fax', '0', '', NULL, '2018-11-27 18:47:36'),
(29, 'contact', 'Email', 'info@mcledger.co', '', NULL, '2018-11-05 03:14:27'),
(30, 'contact', 'Skype', '', '', NULL, NULL),
(31, 'contact', 'WhatsApp', '', '', NULL, '2017-10-11 09:18:52'),
(32, 'contact', 'Map', '29.950679, 30.944023', '', NULL, '2018-11-27 19:47:10'),
(33, 'meta', 'description_home', '', '', NULL, NULL),
(34, 'meta', 'keywords_home', '', '', NULL, NULL),
(35, 'meta', 'description_contact', '', '', NULL, NULL),
(36, 'meta', 'keywords_contact', '', '', NULL, NULL),
(37, 'social', 'google', '', '', NULL, '2018-03-06 20:12:47'),
(38, 'social', 'linkedin', 'https://www.linkedin.com/company/mcledger', '', NULL, '2018-11-05 03:14:27'),
(39, 'contact', 'CustomerService', '', '', NULL, '2018-11-27 18:47:36'),
(44, 'contact', 'MapiFrame', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d791.6988679841066!2d30.94460892151133!3d29.950680243005255!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjnCsDU3JzAyLjQiTiAzMMKwNTYnMzguNSJF!5e1!3m2!1sar!2seg!4v1543324059129\" width=\"100%\" height=\"450\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>', '', NULL, '2018-11-29 15:02:20'),
(45, 'contact', 'MapiFrameHome', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d791.6988679841066!2d30.94460892151133!3d29.950680243005255!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjnCsDU3JzAyLjQiTiAzMMKwNTYnMzguNSJF!5e1!3m2!1sar!2seg!4v1543324059129\" width=\"100%\" height=\"450\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>', '', NULL, '2018-11-29 15:02:20'),
(46, 'site', 'logo', '2018/11/1543049802.png', '', NULL, '2018-11-24 14:56:42');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `unsubscribed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `name`, `email`, `phone`, `unsubscribed`, `created_at`, `updated_at`) VALUES
(4, 'fdsfdsfdsfds', 'fdsfdsfdsfds@mail.com', '', 0, '2019-12-10 06:30:04', '2019-12-10 06:30:04');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `admin`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Marwan', 'marwan.nabil.mohamed@gmail.com', 1, NULL, '$2y$10$Dcfaa0lXZuXUEE5jL/JouuddF22IulZjpjfyi1nyr3RjdG2Aub6RK', 'LDdoq923sjE8xbTQsNCr2YVk2MNZAsYucBn9vxgzsBXB0bzm0ebH6CV4pAct', '2019-11-07 13:32:13', '2019-11-07 13:32:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_authors`
--
ALTER TABLE `blog_authors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_categories`
--
ALTER TABLE `blog_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_comments`
--
ALTER TABLE `blog_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emails`
--
ALTER TABLE `emails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emails_bulk`
--
ALTER TABLE `emails_bulk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiries`
--
ALTER TABLE `enquiries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiry_reply`
--
ALTER TABLE `enquiry_reply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `join_requests`
--
ALTER TABLE `join_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `blog_authors`
--
ALTER TABLE `blog_authors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blog_categories`
--
ALTER TABLE `blog_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `blog_comments`
--
ALTER TABLE `blog_comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `emails`
--
ALTER TABLE `emails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `emails_bulk`
--
ALTER TABLE `emails_bulk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `enquiries`
--
ALTER TABLE `enquiries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `enquiry_reply`
--
ALTER TABLE `enquiry_reply`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `join_requests`
--
ALTER TABLE `join_requests`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
